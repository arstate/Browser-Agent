# 🔍 Rencana Perbaikan: Eliminasi Halusinasi Typo Vision Dokumen PDF/DOCX (Dual-Layer Ground Truth Architecture)

## 📌 Deskripsi Masalah & Analisis Empiris
Pengguna mengirimkan file PDF proposal (`PROPOSAL INDIVIDU ARYA MAGANG KOMINFO (20).pdf` / `(21).pdf`). Saat AI diminta memeriksa/mengaudit revisi dokumen, AI melaporkan adanya typo:
> `Halaman 9 (Subbab 3.1 - Poin 2 Baris Terakhir):`  
> `• Tertulis: ((@surabaya palet merah #D71920).`  
> `• Koreksi: Hapus satu tanda kurung buka dobel menjadi (@surabaya palet merah #D71920).`

Padahal pada dokumen asli, teks yang tertulis adalah tunggal: `(@surabaya palet merah #D71920).`

---

## 🔬 Investigasi Mendalam: Kenapa Hal Ini Terjadi? (3 Akar Masalah Teknis)

Setelah dilakukan investigasi mendalam langsung pada berkas cache dokumen (`~/.browser-agent/cache/document_pages/.../page_009.jpg`) dan stream teks internal PDF:

```
+-----------------------------------------------------------------------------------------+
|                                AKAR MASALAH 1:                                          |
|                 ILUSI OPTIK GLYPH & KERNING FONT TIMES NEW ROMAN                        |
|                                                                                         |
| Pada font Serif (Times New Roman):                                                      |
|   - Karakter kurung buka: "(" berupa kurva vertikal melengkung ke kiri.                 |
|   - Karakter at-sign:     "@" memiliki spiral lingkaran luar (outer arc) berbentuk "C".  |
|                                                                                         |
| Saat karakter "(" dan "@" bersentuhan langsung tanpa spasi -> "(@"                      |
| Kurva "(" dan busur luar "@" berjarak hanya 1-2 piksel, membentuk ilusi dua kurva:     |
|                              ( ( a )                                                    |
| Bagi model Computer Vision (tokenisasi visual patch), ini tampak persis seperti "((".   |
+-----------------------------------------------------------------------------------------+
                                           +
                                           v
+-----------------------------------------------------------------------------------------+
|                                AKAR MASALAH 2:                                          |
|                KOMPRESI JPEG 80 & RESOLUSI 140 DPI (DCT RINGING)                        |
|                                                                                         |
| Di `host/doc_parser.py`:                                                                |
| Halaman dirender pada DPI 140 dengan kompresi JPEG quality 80.                          |
|   - Pada teks 12pt di 140 DPI, tinggi huruf hanya ~23 piksel.                           |
|   - Kompresi kuantisasi Discrete Cosine Transform (DCT) 8x8 pada JPEG memicu            |
|     "ringing artifact" dan edge blur pada celah 1 piksel antara "(" dan "@",            |
|     sehingga kedua garis hitam menyatu secara optik menjadi garis dobel "((".           |
+-----------------------------------------------------------------------------------------+
                                           +
                                           v
+-----------------------------------------------------------------------------------------+
|                                AKAR MASALAH 3:                                          |
|              VISION-OVER-TEXT BIAS & KETIADAAN MANDAT TEKS DIGITAL                      |
|                                                                                         |
| Sistem Browser Agent sebenarnya SUDAH menyertakan stream teks asli via `pdftotext`:    |
|   `[Teks Digital Ground-Truth (Stream Asli) Halaman 9]: ... (@surabaya ...) ...`       |
|                                                                                         |
| Namun, saat pengguna meminta "cek revisian / cek typo", model AI memprioritaskan        |
| citra visual mata (gambar) dan tidak memiliki instruksi strict untuk melakukan          |
| cross-check ke Teks Digital Asli sebelum mengklaim adanya typo.                         |
+-----------------------------------------------------------------------------------------+
```

---

## 🛠️ Solusi Rekayasa Komprehensif (Proposed Changes)

### 1. Penanaman Protokol Dual-Layer Ground Truth Hierarchy pada Core System Prompt
**Berkas:**
- `extension/sidepanel.js` (pada `CHAT_ONLY_SYSTEM_PROMPT` dan `DEFAULT_SYSTEM_PROMPT`)
- `extension/background.js` (pada `systemInstruction` Telegram Bot)

**Aturan yang Disuntikkan:**
1. **Teks Digital Sebagai Sumber Kebenaran Mutlak (Supreme Ground Truth):**
   Untuk dokumen berformat teks (PDF digital, DOCX, XLSX), validasi ejaan, kata ganda, karakter tanda baca, tanda kurung, angka, dan penulisan nama WAJIB merujuk 100% pada `[Teks Digital Asli (Stream Ground Truth)]`.
2. **Larangan Halusinasi Ilusi Optik Kerning/Ligatur:**
   AI secara eksplisit dilarang mengklaim ada tanda kurung buka ganda `((` atau karakter ganda jika pada Teks Digital Asli hanya ada satu karakter. AI diberi tahu secara spesifik bahwa pada font Serif (Times New Roman), simbol `@` memiliki lengkungan luar yang menempel pada `(` sehingga menyerupai `((@` pada raster gambar.
3. **Pemisahan Peran Visual vs Teks:**
   - **Teks Digital**: Khusus untuk konten huruf, ejaan, typo, kata sambung asing (*and* vs *dan*), dan angka.
   - **Gambar Halaman**: Khusus untuk audit tata letak (*layout*), perataan tabel, margin, kerapian baris, tanda tangan basah, dan cap stempel pada halaman gambar/scan.

```javascript
// Cuplikan Aturan Tambahan di System Prompt:
PROTOKOL AUDIT DOKUMEN & ANTI-HALUSINASI VISUAL (DUAL-LAYER GROUND TRUTH):
1. Prioritas Teks Digital Mutlak: Saat memeriksa dokumen (PDF/Word), "[Teks Digital Asli (Stream Ground Truth)]" adalah sumber kebenaran karakter 100% mutlak. Seluruh audit typo, ejaan, tanda baca, tanda kurung, dan angka WAJIB dicross-check langsung ke teks digital ini!
2. Larangan Halusinasi Ilusi Optik Font: Font Serif (seperti Times New Roman) sering menampilkan simbol '@' dengan lingkaran luar yang bersinggungan langsung dengan tanda kurung buka '(', sehingga tampak menyerupai kurung dobel '((@' pada pratinjau gambar. DILARANG KERAS mengklaim ada typo tanda kurung dobel jika pada Teks Digital Asli karakter tersebut hanya tunggal!
3. Pembagian Peran Dual-Layer:
   - Gunakan Teks Digital untuk: ejaan kata, tanda baca, data angka, sitasi.
   - Gunakan Gambar Visual untuk: layout, kerapian tabel, margin, logo, tanda tangan, dan halaman scan.
```

---

### 2. Penguatan Header Stream Teks Digital pada Message Payload Builder
**Berkas:**
- `extension/sidepanel.js` (pada fungsi `sendMessageToAI` baris 6392 dan `runChatModeLoop` baris 8730)

**Penyempurnaan Label Prompt:**
```javascript
// Sebelum:
const textSnippet = p.text ? `\n[Teks Digital Ground-Truth (Stream Asli) Halaman ${pNum}]:\n${p.text}\n` : '';

// Sesudah:
const textSnippet = p.text ? `\n[Teks Digital Asli (Stream Ground Truth Ejaan & Karakter) Halaman ${pNum}]:\n${p.text}\n[⚠️ PANDUAN AUDIT TYPO: Teks Digital di atas diekstrak langsung dari byte font internal file. Jika pada gambar visual di bawah tampak kurung ganda atau glif menempel (misal '(@' tampak seperti '((@'), WAJIB jadikan Teks Digital di atas sebagai sumber kebenaran 100%. DILARANG melaporkan ilusi optik rendering font sebagai typo!]\n` : '';
```

---

### 3. Peningkatan Ketajaman Raster Gambar Dokumen (150 DPI & Quality 88)
**Berkas:**
- `host/doc_parser.py`
- `host/native_host.py`
- `host/rust_host/src/main.rs`

**Optimalisasi:**
- Mengubah DPI default dari `140` ke `150` DPI.
- Mengubah JPEG quality default dari `80` ke `88` dengan `-jpegopt quality=88,progressive=y`.
- Menghilangkan noise kuantisasi DCT 8x8 pada celah piksel karakter rapat tanpa membengkakkan ukuran payload (hanya ~280 KB per halaman).

---

## 🧪 Rencana Verifikasi (Verification Plan)

### Automated Tests
1. Sintaksis JavaScript:
   ```bash
   node -c extension/sidepanel.js
   node -c extension/background.js
   ```
2. Sintaksis Python:
   ```bash
   python3 -m py_compile host/doc_parser.py host/native_host.py
   ```
3. Kompilasi Rust Host:
   ```bash
   cd host/rust_host && cargo check
   ```
4. Kepatuhan Aturan Sub-800 Baris:
   ```bash
   wc -l extension/design/*.js extension/apps-integration/*.js
   ```

### Manual Verification
1. Uji ekstraksi dokumen `PROPOSAL INDIVIDU ARYA MAGANG KOMINFO (21).pdf` pada Halaman 9:
   - Pastikan teks digital stream terbaca `(@surabaya palet merah #D71920).`
   - Pastikan instruksi peringatan typo tersemat rapi di payload.
2. Pastikan AI tidak lagi melaporkan adanya kurung buka dobel `((@`.
