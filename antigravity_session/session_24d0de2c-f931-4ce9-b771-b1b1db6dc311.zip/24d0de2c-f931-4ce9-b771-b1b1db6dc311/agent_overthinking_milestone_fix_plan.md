# 🧠 ANALISIS & RENCANA PERBAIKAN: AGENT OVERTHINKING & MILESTONE LOOPING

Dokumen ini membedah secara tuntas penyebab teknis mengapa **Browser Agent** yang sudah memberikan jawaban benar tiba-tiba **mikir lagi**, merusak output yang sudah benar, dan bagaimana solusi arsitektur untuk mengatasinya secara permanen.

---

## 🔍 1. ANATOMI MASALAH: APA YANG SEBENARNYA TERJADI?

Fenomena ini dalam dunia AI Multi-Agent & LLM dikenal sebagai **"The Goal Over-Refinement Trajectory Collapse"** (atau *Overthinking & Self-Doubt Loop* akibat penjaga milestone yang terlalu kaku).

Alurnya terjadi seperti ini:
```
[User Request] 
      │
      ▼
1. GoalTracker membuat 4-5 Milestone otomatis (termasuk "Validasi Kualitas 100% Perfeksionis")
      │
      ▼
2. Step 1: Agent panggil Tool (misal: baca dokumen / buka browser / cari data)
      │  └── Tool sukses & data valid didapatkan!
      ▼
3. Step 2: Model LLM menyusun jawaban lengkap & benar (100% menjawab user) tanpa panggil tool lagi.
      │  └── Teks jawaban yang benar DITAMPILKAN di layar user (User sempat lihat jawaban bener).
      ▼
4. [BUG TERJADI DI SINI - Completion Guard]
   Sistem mengecek: Apakah milestone masih ada yang berstatus pending?
   Karena Agent kerja CEPAT (hanya butuh 1 step tool), sistem mengira:
   "Loh, Milestone 2, 3, dan 4 kan belum dicentang! Berarti tugas BELUM SELESAI!"
      │
      ▼
5. [Injeksi Prompt Keras ke LLM]
   Sistem menyuntikkan pesan user palsu ke model:
   "🛑 [SYSTEM GOAL COMPLETION GUARD]: Tugas BELUM selesai! Masih ada Milestone tertunda! DILARANG BERHENTI!"
      │
      ▼
6. [LLM Panik, Self-Doubt & Overthinking]
   Model LLM yang baru saja menjawab benar menerima teguran keras: "TUGAS BELUM SELESAI!".
   Model berpikir: "Waduh, berarti jawaban gue tadi salah atau ditolak boss!".
   Model mulai meragukan hasil sebelumnya, halusinasi, atau sok ngide ngasih jawaban lain.
      │
      ▼
7. [UI Overwrite Bencana]
   Di Step 3, teks baru yang ngelantur/salah ini MENIMPA (overwrite) teks jawaban benar di bubble chat!
   Hasil akhir: Jawaban yang tadinya sudah benar hilang, digantikan jawaban yang ngaco!
```

---

## 💥 2. EMPAT AKAR MASALAH UTAMA (ROOT CAUSES)

### 1. Perhitungan Progres Naif Berdasarkan Jumlah Tool (`toolCount / 2`)
Di dalam `extension/core/goal_tracker.js`:
```javascript
// Menghitung milestone aktif hanya berdasarkan pembagian tool:
const currentWorkerOffset = Math.min(
  workerMilestonesCount - 1,
  Math.floor(toolCount / 2)
);
const activeWorkerIdx = 1 + currentWorkerOffset;
```
- **Masalah:** Sistem mengasumsikan setiap milestone butuh minimal **2 tool calls**.
- Jika agen sangat pintar dan bisa menyelesaikan tugas hanya dengan **1 tool call** (atau data sudah langsung ketemu), milestone berikutnya tidak akan pernah tercentang secara otomatis.
- **Akibat:** Agen yang cerdas dan efisien justru dihukum dan dianggap "belum selesai".

### 2. Penjaga Kelulusan Kaku (`hasPendingMilestones`) Memaksa Looping
Di dalam `extension/sidepanel.js` (baris 7172–7186) dan `extension/background.js` (baris 3871–3883):
```javascript
} else {
  // Model tidak memanggil tool (ingin mengakhiri dan memberikan teks jawaban final)
  const hasPending = GoalTracker.hasPendingMilestones(activeGoalMilestones, conversationHistory);

  if (hasPending && currentStep < maxSteps - 2) {
    const contPrompt = GoalTracker.generateGoalContinuationPrompt(activeGoalMilestones);
    conversationHistory.push({
      role: "user",
      content: contPrompt
    });
    continue; // <--- LOOPING DIPAKSA BERLANJUT!
  }
}
```
- Walaupun model sudah mengirim jawaban final, sistem mencegatnya dan memaksanya melanjutkan loop hanya karena daftar milestone template belum tercentang semua.

### 3. Prompt Penegur Agresif Memicu "LLM Sycophancy & Hallucination"
Prompt yang disuntikkan oleh `generateGoalContinuationPrompt`:
```text
🛑 [SYSTEM GOAL COMPLETION GUARD]:
Tugas BELUM selesai! Masih ada Milestone yang tertunda dan belum dieksekusi tuntas:
• Milestone 3: ...
MANDAT:
Lanjutkan eksekusi langkah berikutnya sekarang juga menggunakan tool browser / bash / manipulasi data yang sesuai. DILARANG berhenti sebelum seluruh Milestone di atas terselesaikan 100%!
```
- Dalam riset AI alignment, jika LLM dibentak dengan perintah *"Jawabanmu belum selesai / dilarang berhenti"*, model akan mengalami fenomena **sycophantic over-correction**: model menganggap jawaban sebelumnya tidak diinginkan, sehingga model akan mengarang asumsi baru, mengubah kesimpulan, atau menghasilkan data halusinasi.

### 4. Overwrite Konten Bubble Tanpa Pengaman
Di `extension/sidepanel.js`, saat model masuk ke step berikutnya (Step 3):
```javascript
// Di step berikutnya:
accumulatedContent += delta.content;
updateAssistantText(assistantBubble, accumulatedContent, true);
// contentEl.innerHTML = formatMarkdown(text);
```
- Teks yang sudah tampil di layar pada Step 2 langsung **dihapus bersih dan diganti** dengan teks Step 3. Pengguna melihat jawaban yang sudah benar tiba-tiba "terhapus" dan berubah menjadi salah.

---

## 🛠️ 3. RENCANA SOLUSI PERMANEN (EARLY-EXIT & SEMANTIC SATISFACTION)

Untuk menyelesaikan masalah ini secara tuntas tanpa menghilangkan fitur pelacakan sasaran (Goal Tracker), kita terapkan 4 pilar arsitektur baru:

```mermaid
graph TD
    A[Model Menghasilkan Respon Teks] --> B{Ada Tool Calls Baru?}
    B -- Ya --> C[Jalankan Tool & Update Progres]
    C --> A
    B -- Tidak --> D{Apakah Teks Sudah Menjawab Pertanyaan?}
    D -- Ya (Substantif > 30 Karakter) --> E[🎯 Semantic Early-Exit Triggered]
    E --> F[Tandai SEMUA Sisa Milestone Selesai / 100%]
    F --> G[Hentikan Loop Segera (Break)]
    F --> H[Kunci Jawaban di Layar (Anti-Overwrite)]
    D -- Belum / Error Tool --> I[Cek Apakah Butuh Tindak Lanjut Nyata]
```

### Pilar 1: Early-Exit saat Substantive Answer Tercapai (Anti-Overthinking)
- Jika model menghasilkan teks jawaban substansial (bukan sekadar *"tunggu sebentar ya"* atau teks kosong) dan **TIDAK meminta tool call lagi**, sistem harus menghormati bahwa model sudah selesai.
- **Tindakan:** Langsung tandai seluruh sisa milestone menjadi `completed: true`, perbarui UI progress menjadi 100%, dan lakukan `break` keluar dari loop. JANGAN paksa `continue`!

### Pilar 2: Auto-Fulfillment Milestone Template
- Jika tugas selesai lebih cepat dari estimasi langkah (misal selesai di step 2 dari rencana 4 step), sistem secara cerdas melakukan **Auto-Fulfill**:
  ```javascript
  // Jika model selesai memberikan teks tanpa tool call:
  if (activeGoalMilestones && Array.isArray(activeGoalMilestones)) {
    activeGoalMilestones.forEach(m => {
      m.completed = true;
      m.inProgress = false;
    });
    updateTaskScheduleProgress(assistantBubble, activeGoalMilestones, activeGoalMilestones.length, false);
  }
  ```

### Pilar 3: Non-Destructive Injeksi & Hapus Bentakan Keras
- `generateGoalContinuationPrompt` hanya boleh aktif JIKA:
  1. Turn sebelumnya menghasilkan **error fatal tool** yang belum ditangani.
  2. Model belum mengeluarkan teks jawaban sama sekali (jawaban kosong).
- Ubah nada prompt menjadi analitis dan objektif, bukan bentakan agresif yang membuat LLM panik/halusinasi.

### Pilar 4: Bubble Text Protection (Anti-Wipeout)
- Jika agen memang harus melakukan langkah verifikasi tambahan, jawaban yang sudah ada tidak boleh ditimpa (`overwrite`).
- Jawaban awal dipertahankan, dan hasil verifikasi ditambahkan sebagai catatan pendukung atau konfirmasi, bukan menghapus teks yang sudah benar.

---

## 📋 4. DAFTAR FILE YANG AKAN DIPERBAIKI

| No | File | Fokus Perubahan |
|---|---|---|
| 1 | `extension/sidepanel.js` | Mencegah looping paksa di baris 7172. Jika model mengembalikan teks tanpa tool calls, segera aktifkan Early Exit dan tandai semua milestone 100% tuntas. |
| 2 | `extension/background.js` | Sinkronisasi logika yang sama di background runner (baris 3871). |
| 3 | `extension/core/goal_tracker.js` | Menyesuaikan `hasPendingMilestones` agar tidak pernah memicu loop jika jawaban substantif sudah dihasilkan. Memperhalus prompt penjaga agar bebas dari efek halusinasi overthinking. |

---

## 🎯 5. DAMPAK & KEUNTUNGAN SETELAH PERBAIKAN
1. **100% Jawaban Benar Terkunci:** Agen tidak akan pernah lagi meralat jawaban yang sudah benar atau membuatnya jadi salah.
2. **Respon Jauh Lebih Cepat:** Menghemat token dan waktu tunggu karena agen tidak looping memikirkan hal yang tidak perlu.
3. **Milestone Tetap Rapi & Elegan:** Seluruh checklist tugas otomatis tercentang hijau (100% Selesai) begitu jawaban final muncul, memberikan kepuasan visual maksimal bagi pengguna.
