# 🧠 Rencana Solusi: Anti-Lupa (Long-Term Document Knowledge) & Anti-Nyampah (Smart Ephemeral Rendering)

## 🎯 Goal & Problem Statement
Pengguna mengajukan kekhawatiran kritis:
> *"Tapi kalo gue di masa depan tanya lagi, AI-nya gatau dong, dia lupa dong, gimana ya bro solusinya?"*

Jika file gambar JPG halaman (`page_001.jpg` s/d `page_020.jpg`) dibersihkan dari penyimpanan lokal demi mencegah penumpukan sampah (*disk bloat*), bagaimana cara memastikan **AI TIDAK PERNAH LUPA** isi dokumen tersebut saat ditanya kembali di masa depan (baik di sesi yang sama maupun di sesi obrolan baru)?

Rencana ini merumuskan arsitektur **3-Tier Document Memory & On-Demand Visual Re-Hydration**: memisahkan antara **Pengetahuan Permanen (Knowledge Layer)** yang sangat ringan (hanya beberapa kilobyte di SQLite/Memory) dan **Rendering Visual Sementara (Ephemeral Viewport Layer)**, sehingga penyimpanan lokal tetap lega dan AI tetap jenius mengingat seluruh dokumen selamanya.

---

## 💡 Prinsip Emas: Bagaimana AI "Mengingat" Dokumen Tanpa Nyampah?

Banyak yang mengira AI membutuhkan puluhan file JPG tersimpan di folder disk agar bisa mengingat dokumen. **Faktanya tidak demikian:**

| Jenis Data | Ukuran di Disk | Apakah Harus Disimpan Selamanya? | Fungsi untuk AI |
| :--- | :--- | :--- | :--- |
| **File Dokumen Asli (Master PDF/Word)** | ~800 KB | **YA (Tersimpan Permanen)** di `~/.browser-agent/uploads/` | Sumber kebenaran asli (*Ground Truth*). Bisa dibuka pengguna via *"Open File"*. |
| **Teks Lengkap & Ringkasan Bab (Markdown & Metadata)** | ~15 KB (200x lebih hemat!) | **YA (Tersimpan Permanen)** di SQLite `uploaded_files` & `user_memories` | Otak & memori AI untuk menjawab pertanyaan tentang isi, bab, dan data dokumen di masa depan. |
| **File Gambar JPG Tiap Halaman (`page_001.jpg`..)** | ~3.5 MB per dokumen | **TIDAK (Cache Sementara / Viewport)** | Hanya dibutuhkan sekali saat analisis visual (sudah di-encode ke memory base64 browser). |

> [!NOTE]
> **Kunci Solusi Anti-Lupa:**
> 1. File asli PDF proposal (`.pdf`) **TIDAK PERNAH DIHAPUS**.
> 2. Teks lengkap per bab dokumen **DISIMPAN PERMANEN** di SQLite database (hanya 15 KB).
> 3. AI memiliki tool bawaan `view_document`. Jika di masa depan pengguna meminta: *"Coba cek lagi visual tabel di halaman 5 dong!"*, AI tinggal memanggil `view_document` untuk me-render halaman 5 dalam **0.5 detik** dari file PDF aslinya yang masih ada!
> 
> **Hasilnya**: Penyimpanan 100% bersih dari tumpukan ratusan JPG lama, dan AI 100% **TIDAK PERNAH LUPA** karena punya Master PDF dan Teks Lengkap di memorinya!

---

## 🏗️ Arsitektur 3-Tier Document Memory System

```mermaid
graph TD
    subgraph 1. Upload & Ekstraksi
        A[Pengguna Upload PDF Proposal 20 Hal] --> B[Simpan Master PDF ke ~/.browser-agent/uploads/ - 850 KB]
        B --> C[doc_parser.py: Ekstrak Teks Digital & Render Cache Visual]
    end

    subgraph 2. Penyimpanan Memori Jangka Panjang (Anti-Lupa Permanen)
        C --> D[(SQLite: uploaded_files)]
        D -->|Teks Lengkap 20 Halaman| E[Parsed Markdown - 15 KB]
        C --> F[(SQLite: user_memories)]
        F -->|Index Pengetahuan Dokumen| G[Memory Card: Judul, Daftar Isi, Bab 1-N, Lokasi File]
        C --> H[(SQLite: sessions)]
        H -->|Riwayat Chat & Analisis AI| I[Messages History Permanen]
    end

    subgraph 3. Visual Viewport & Smart Lifecycle (Anti-Nyampah)
        C --> J[Folder Cache Halaman: ~/.browser-agent/cache/pages_...]
        J --> K[Base64 Memory Dikirim ke AI Vision Turn Ini]
        J -.->|Auto-Purge TTL 24 Jam / Kuota 50 MB| L[Cache JPG Dibersihkan Aman]
    end

    subgraph 4. Skenario Masa Depan (Tanya Lagi Minggu Depan)
        M[Pengguna: 'Bro, proposal kemarin bab 2 ngebahas apa ya?'] --> N{AI Cek Context & SQLite Memory}
        N -->|Teks & Analisis Sudah Ada di Memori| O[AI Langsung Jawab Cepat & Akurat!]
        P[Pengguna: 'Cek lagi dong gambar/tabel di halaman 8!'] --> Q[AI Panggil Tool: view_document]
        Q -->|Buka Master PDF Asli| R[Render Ulang Halaman 8 Instan: 0.5 Detik]
        R --> S[AI Analisis Visual Halaman 8 Sempurna]
    end
```

---

## 🚀 Rencana Fitur & Implementasi Detail

### 1. Document Knowledge Indexing ke `user_memories` (Eternal Memory)
Saat sebuah dokumen diunggah dan di-parse:
- Backend mengekstrak metadata penting:
  - Nama Dokumen, Ukuran, Total Halaman.
  - Ringkasan Daftar Isi / Judul Bab (misal: Bab I Hal 4, Bab II Hal 7).
  - Path lokasi master file: `/home/arya/.browser-agent/uploads/...`
- Metadata ini otomatis didaftarkan ke tabel `user_memories` (kategori: `document_knowledge` / `uploaded_document`).
- **Dampaknya**:
  - Bahkan jika pengguna membuka sesi obrolan baru 1 bulan kemudian dan bertanya:
    *"Bro, proposal magang Kominfo gue kemarin judul resminya apa ya dan ada berapa bab?"*
  - AI akan langsung mengenali dokumen tersebut dari Personal Memory tanpa perlu upload ulang!

### 2. Smart Ephemeral Cache dengan On-Demand Re-Hydration
- Folder gambar halaman disimpan terisolasi di `~/.browser-agent/cache/document_pages/`.
- **Auto-Purge**:
  - Folder JPG halaman yang tidak diakses selama > 24 jam atau total cache > 50 MB otomatis dibersihkan.
- **On-Demand Lazy Re-Hydration**:
  - Jika pengguna atau AI membutuhkan inspeksi visual ulang lembar halaman tertentu di masa depan, tool `view_document` akan me-render halaman tersebut secara on-demand langsung dari Master PDF aslinya yang tersimpan aman di `uploads/`.
  - Karena engine `doc_parser.py` kita sudah super cepat (0.5 detik per halaman), proses re-render ini berjalan instan tanpa lag.

### 3. Quick-Action "Buka Dokumen Asli" & Status Penyimpanan
- Di UI Chat, kartu dokumen tetap menampilkan tombol `Open File` (membuka file PDF asli di sistem OS default reader) dan `Reveal File` (membuka folder).
- Di menu Pengaturan (Settings modal & NewTab options), ditambahkan statistik penyimpanan:
  - `Master Files (PDF/Doc)`: Menampilkan total ukuran dokumen asli.
  - `Visual Page Cache`: Menampilkan ukuran cache JPG (dengan indikator status: *Otomatis dibersihkan berkala*).
  - Tombol aksi `[ 🧹 Bersihkan Cache Visual Sekarang ]` untuk membebaskan ruang seketika.

---

## ❓ Konfirmasi & Keputusan Pengguna

> [!TIP]
> **Apakah alur solusi di atas sudah sesuai dengan yang Anda harapkan?**
> 
> Dengan arsitektur ini:
> 1. **AI Dijamin 100% Ingat Selamanya**: Teks dokumen, struktur bab, dan riwayat analisis tersimpan permanen di SQLite & Personal Memory.
> 2. **Master PDF Tetap Aman**: File PDF asli tidak dihapus, siap dibuka kapan saja.
> 3. **Penyimpanan Bebas Sampah**: File JPG halaman (yang ukurannya puluhan kali lebih besar) berstatus cache sementara yang otomatis dibersihkan secara cerdas, dan bisa di-render ulang instan kapan pun AI membutuhkannya lagi.

Jika Anda menyetujui rencana ini, klik tombol **Proceed** atau beri konfirmasi agar kami segera mengimplementasikannya!
