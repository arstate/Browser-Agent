# 🛡️ Implementation Plan: Pencegahan Pembajakan Mode (Agent Mode Hijacking) & Eliminasi False-Positive Design Mode

## 🎯 Goal Description
Pengguna melaporkan bahwa saat berada di **Agent Mode** (`currentChatMode === 'agent'`), ketika mengirim prompt yang panjang atau berisi banyak teks ("kirim prompt banyak"), sistem secara sepihak dan tiba-tiba **mengubah mode ke Design Mode** (`setChatMode('design')`), mengalihkan eksekusi ke `runDesignModeLoop`, dan memicu error karena mesin generator slide deck 16:9 tidak dirancang untuk memproses instruksi/kode agent.

Rencana ini akan:
1. Menjamin **Mode Primacy mutlak**: Jika pengguna sedang berada di **Agent Mode**, sistem **DILARANG KERAS** membajak mode dan dilarang mengubah mode ke `design`. Seluruh permintaan di Agent Mode harus 100% diproses oleh `runAgentLoop`.
2. Memperbaiki regex **`isExplicitSlideDeckIntent`** dan **`isSlideDeckRevisionInstruction`** agar tidak memicu false-positive hanya karena ada kata tunggal seperti `"presentasi"`, `"presentation"`, `"ppt"`, atau `"halaman"`.
3. Menyelaraskan router di `handleSendMessage` dan `processNextQueuedPrompt` agar mode aktif pengguna selalu dipertahankan.

---

## 🔍 Root Cause Analysis (Akar Masalah)

1. **Auto-Switching Terlalu Agresif di Router (`extension/sidepanel.js` baris 14945-14950 & 14655-14660)**:
   ```javascript
   } else if (isExplicitSlide && !isExplicitExternalWeb && currentChatMode !== 'chat') {
     if (typeof setChatMode === 'function') setChatMode('design');
     runDesignModeLoop(displayMessage, currentAttachments, currentMentions);
   } else if (isDeckRevisionReq && !isExplicitExternalWeb && currentChatMode !== 'chat') {
     runDesignModeLoop(displayMessage, currentAttachments, currentMentions, { isRevision: true });
   ```
   - Kondisi `currentChatMode !== 'chat'` bernilai `true` saat pengguna berada di **Agent Mode** (`currentChatMode === 'agent'`).
   - Akibatnya, jika prompt pengguna mengandung kata yang memicu `isExplicitSlide` atau `isDeckRevisionReq`, router mengeksekusi `setChatMode('design')`, mengubah pill UI ke Design Mode, dan membelokkan eksekusi ke `runDesignModeLoop`!

2. **Regex Overly Broad pada `isExplicitSlideDeckIntent` (`extension/sidepanel.js` baris 973)**:
   ```javascript
   const hasSlideKeyword = /(?:slide\s*deck|presentasi|presentation|powerpoint|ppt\b|bikin\s+slide\s*deck|buat\s+slide\s*deck|deck\s*presentasi)/i.test(text);
   ```
   - Kata tunggal `"presentasi"`, `"presentation"`, atau `"ppt"` berdiri sendiri akan mengevaluasi `true`.
   - Padahal dalam prompt panjang pengguna (analisis bisnis, materi kuliah, tugas, atau kode), kata "presentasi" sangat lumrah disebut tanpa bermaksud meminta AI men-generate slide deck 16:9 saat itu juga!

3. **Target Terlalu Luas pada `isSlideDeckRevisionInstruction` (`extension/sidepanel.js` baris 983)**:
   ```javascript
   const hasDeckTarget = /(?:slide\s*deck|slide\b|deck\b|halaman|warna\s+slide|layout\s+slide|presentasi|ppt)/i.test(text);
   ```
   - Kata `"halaman"` (misalnya: *"tolong edit halaman login"*, *"tambah halaman baru di web"*, *"update halaman settings"*) dipadukan dengan kata kerja revisi (`edit`, `tambah`, `update`) otomatis dianggap revisi slide presentasi jika canvas pernah dibuka!

4. **Kegagalan di `runDesignModeLoop`**:
   - Ketika prompt panjang Agent dialihkan ke `runDesignModeLoop`, fungsi ini mengasumsikan input berupa topik presentasi ringkas dan mencoba mengekstrak tema/slide count. Akibatnya, API call atau parser internal mengalami crash / error.

---

## 👥 User Review Required
> [!IMPORTANT]
> **Aturan Utama Mode Primacy**:
> - Ketika pengguna memilih **Agent Mode**, pengguna memegang kendali penuh atas mode tersebut.
> - Sistem tidak akan pernah secara otomatis mengubah dropdown mode pengguna ke **Design Mode**.
> - Jika pengguna di Agent Mode meminta dibuatkan slide presentasi (misal *"buatkan slide presentasi tentang AI"*), Master Agent di `runAgentLoop` tetap menangani permintaan tersebut dan dapat memanggil tool `create_slide_deck_design` secara mandiri tanpa mengubah mode UI pengguna.
> - Mode Design hanya akan aktif jika pengguna secara sadar memilih **Design Mode** dari dropdown mode, atau menekan tombol konfirmasi khusus.

---

## ❓ Open Questions
Tidak ada pertanyaan terbuka yang menghambat. Solusi ini menjaga kestabilan mode dan mematuhi prinsip *least surprise*.

---

## 🛠️ Proposed Changes

### Component: Router & Prompt Dispatcher (`extension/sidepanel.js`)

#### [MODIFY] `extension/sidepanel.js`

1. **Perketat Regex `isExplicitSlideDeckIntent` & `isSlideDeckRevisionInstruction`**:
   - Hapus kata tunggal `"presentasi"`, `"presentation"`, `"ppt"` dari `hasSlideKeyword`. Hanya frasa eksplisit seperti `slide deck`, `deck presentasi`, `powerpoint deck`, atau perintah `buat/bikin/rancang ... presentasi` yang lolos.
   - Hapus kata tunggal `"halaman"` dari `hasDeckTarget` (ganti dengan `halaman slide`).

   ```javascript
   function isExplicitSlideDeckIntent(text = '') {
     if (!text || typeof text !== 'string') return false;
     if (isSocialMediaOrImagePrompt(text)) return false;
     // Hanya frasa eksplisit terpadu, BUKAN kata tunggal presentasi/presentation biasa
     const hasSlideKeyword = /(?:slide\s*deck|deck\s*presentasi|presentation\s*deck|powerpoint\s*deck)/i.test(text);
     const hasCreateSlide = /(?:buat|bikin|rancang|generate|create|siapkan)\s+(?:(?:sebuah|beberapa|\d+)\s+)?(?:slide\s*deck|presentasi|presentation|powerpoint|ppt)\b/i.test(text);
     const hasSlideHeader = /^(?:slide\s*deck|deck\s*presentasi)\s*[:=]/i.test(text);
     return Boolean(hasSlideKeyword || hasCreateSlide || hasSlideHeader);
   }

   function isSlideDeckRevisionInstruction(text = '') {
     if (!text || typeof text !== 'string') return false;
     if (isSocialMediaOrImagePrompt(text)) return false;
     const hasRevisionAction = /(?:revisi|ubah|ganti|edit|tambah|kurang|hapus|split|pisah|perbaiki|update|sesuaikan|rombak)/i.test(text);
     // Gunakan 'halaman slide' bukan 'halaman' generik agar tidak mendeteksi halaman web/dokumen
     const hasDeckTarget = /(?:slide\s*deck|slide\b|deck\b|halaman\s+slide|warna\s+slide|layout\s+slide)/i.test(text);
     return Boolean(hasRevisionAction && hasDeckTarget);
   }
   ```

2. **Perbaiki Router `handleSendMessage` (baris ~14935)**:
   - Jika `currentChatMode === 'agent'`, selalu utamakan `runAgentLoop`. Jangan izinkan pembajakan mode ke `design`.
   - Hanya jalankan `runDesignModeLoop` jika `currentChatMode === 'design'`, ATAU jika pengguna secara eksplisit berada di luar mode agent dan kanvas sedang aktif terbuka.

   ```javascript
   if (currentChatMode === 'design') {
     const isRevision = Boolean(canvasIsOpen && activeArt && activeArt.html);
     if (isRevision && !isExplicitExternalWeb) {
       runDesignModeLoop(displayMessage, currentAttachments, currentMentions, { isRevision: true });
     } else {
       runDesignModeLoop(displayMessage, currentAttachments, currentMentions);
     }
   } else if (currentChatMode === 'agent') {
     // Mode Agent Primacy: Tidak boleh dibajak ke Design Mode!
     runAgentLoop(displayMessage, currentAttachments, currentMentions);
   } else if (currentChatMode === 'chat') {
     runChatModeLoop(displayMessage, currentAttachments, currentMentions);
   } else if (hasAgentActionOrAnalysis) {
     runAgentLoop(displayMessage, currentAttachments, currentMentions);
   } else {
     runAgentLoop(displayMessage, currentAttachments, currentMentions);
   }
   ```

3. **Perbaiki Router Antrean `processNextQueuedPrompt` (baris ~14645)**:
   - Terapkan logika yang sama: jika `nextItem.chatMode === 'agent'`, jalankan `runAgentLoop` dan jangan panggil `setChatMode('design')`.

---

## 🧪 Verification Plan

### Automated Tests
1. **Unit Test Regex Semantik**:
   Uji string uji berikut dengan script Node.js:
   - `"Tolong buatkan analisis data penjualan untuk bahan presentasi saya besok"` -> `isExplicitSlideDeckIntent` harus `false` (tidak membajak mode).
   - `"Perbaiki halaman login dan tambahkan validasi form"` -> `isSlideDeckRevisionInstruction` harus `false`.
   - `"Buatkan slide deck 16:9 tentang strategi AI Marketing"` -> `isExplicitSlideDeckIntent` harus `true`.
   - `"Revisi slide 2 ganti warna background jadi navy"` -> `isSlideDeckRevisionInstruction` harus `true`.
2. **Syntax Check**:
   - `node -c extension/sidepanel.js` untuk memastikan tidak ada kesalahan sintaks.
3. **Sub-800 Line Rule Verification**:
   - `wc -l extension/design/*.js` memastikan seluruh 10 file tetap strictly `<= 798` baris.

### Manual Verification
1. Masuk ke **Agent Mode** di New Tab / Side Panel.
2. Ketik prompt panjang berisi kata "presentasi" atau "halaman" (contoh: rencana analisis, review dokumen).
3. Klik tombol kirim.
4. Verifikasi bahwa mode TETAP di **Agent Mode** (tidak berubah menjadi "Design Mode"), dan asisten memproses prompt di loop Master Agent secara normal tanpa error.
