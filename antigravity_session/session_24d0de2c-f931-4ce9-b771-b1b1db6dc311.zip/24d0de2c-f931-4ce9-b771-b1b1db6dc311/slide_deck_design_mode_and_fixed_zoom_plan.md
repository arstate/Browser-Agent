# 📋 Rencana Implementasi: Slide Deck Accuracy, Fixed 16:9 Zoom, Windows PDF Export & Temporary Chat

Dokumen ini merangkum analisis akar masalah teknis dan arsitektur solusi untuk 4 kebutuhan pengguna:
1. **Mode Design Awal Gagal Paham Brief (Materi Ngawur)** vs Paham saat di Open Canvas (Revisi).
2. **Slide Deck Preview di Canvas Malah "Responsif" & Pecah saat Di-zoom** (Harusnya Fixed 16:9).
3. **Error Ekspor Slide Deck PDF di Windows** ("open design error...").
4. **Fitur Baru: Tombol Temporary Chat (Icon Only)** di Header Home (sesuai kotak merah di screenshot pengguna).

---

## 🔍 1. Analisis Akar Masalah Teknis

### 🔴 Masalah 1: Mode Design Awal Materi Ngawur vs Paham di Open Canvas
- **Penyebab Utama:**
  1. [`extension/design/design_agent.js:195-201`](file:///home/arya/browser-agent/extension/design/design_agent.js#L195-L201): Fungsi `cleanPresentationTopic` memangkas brief prompt pengguna dan **memotongnya menjadi maksimal 45 karakter**. Seluruh rincian slide, target audiens, angka, dan outline pengguna dibuang.
  2. [`extension/design/design_agent.js:229`](file:///home/arya/browser-agent/extension/design/design_agent.js#L229): `createDefaultBlueprint` membuat outline kaku bawaan (preset hardcoded), mengabaikan outline yang diminta pengguna.
  3. [`extension/design/design_executor.js:53-56`](file:///home/arya/browser-agent/extension/design/design_executor.js#L53-L56): `fetchSlideContentFromAI` hanya mengirimkan `cleanTopic` (potongan 45 huruf) dan judul preset ke LLM. Prompt asli pengguna (`userMessage`) **tidak pernah disertakan**.
  4. **Kenapa di Open Canvas Paham?** Pada alur revisi di [`design_executor.js:314`](file:///home/arya/browser-agent/extension/design/design_executor.js#L314), sistem mengirimkan **seluruh `userMessage` utuh** bersama HTML aktif ke LLM, sehingga LLM membaca seluruh detail instruksi pengguna.

### 🔴 Masalah 2: Slide Deck Preview Responsif & Pecah Saat Browser Di-zoom
- **Penyebab Utama:**
  1. [`extension/design/slide_styles.js:247-255`](file:///home/arya/browser-agent/extension/design/slide_styles.js#L247-L255): `.slide-section` menggunakan CSS fluid `width: min(1200px, 100%, ...)`.
  2. Elemen internal slide menggunakan pixel statis (`font-size: 42px`, `font-size: 30px`, `padding: 42px 54px`, `gap: 24px`).
  3. Saat browser di-zoom in atau ukuran panel menyempit, wadah slide mengecil, namun ukuran font tetap besar. Akibatnya teks melompat baris (*word-wrapping*), layout 3-kolom terjepit, dan elemen meluap (*overflow*) keluar dari batas 16:9.
  4. Slide presentasi profesional (seperti Google Slides, Canva, atau PowerPoint) menggunakan **Fixed Virtual Canvas (1200x675 px)** dan diskalakan via **CSS `transform: scale(...)`**, sehingga semua elemen membesar/mengecil 100% proporsional tanpa reflow.

### 🔴 Masalah 3: Error Ekspor Slide Deck PDF di Windows
- **Penyebab Utama:**
  1. [`host/native_host.py:3915-3916`](file:///home/arya/browser-agent/host/native_host.py#L3915-L3916): Path berkas sementara di-hardcode ke `/tmp/deck_{ts}.html` dan `/tmp/{clean_title}_{ts}.pdf`. Pada OS Windows, direktori `/tmp/` tidak ada, sehingga memicu `FileNotFoundError`.
  2. [`host/native_host.py:3941-3950`](file:///home/arya/browser-agent/host/native_host.py#L3941-L3950): Daftar executable Chrome hanya memuat path Linux (`/usr/bin/google-chrome`, dsb.). Path Windows (`C:\Program Files\Google\Chrome\Application\chrome.exe` atau `msedge.exe`) tidak ada.
  3. [`host/rust_host/src/main.rs:1410`](file:///home/arya/browser-agent/host/rust_host/src/main.rs#L1410): Menggunakan command `which` yang tidak ada di Windows (Windows memakai `where`).
  4. Frontend [`canvas_exporter.js`](file:///home/arya/browser-agent/extension/design/canvas_exporter.js) langsung menampilkan pesan error tanpa fallback mulus ke dialog cetak native `window.print()` jika RPC gagal.

### 💡 Kebutuhan 4: Tombol Temporary Chat (Icon Only) di Home Header
- **Lokasi:** Di pojok kanan atas Home Header (`.header-right`), sejajar dengan chip status (sesuai kotak merah pada screenshot `uploaded_media_1788890462285.png`).
- **Fungsi:** Mode obrolan sementara (ephemeral) yang **tidak disimpan ke IndexedDB / riwayat percakapan**, tidak memunculkan entri sesi di sidebar, dan langsung bersih saat berganti percakapan.

---

## 🛠️ 2. Arsitektur Solusi Rekayasa

```mermaid
graph TD
    subgraph "1. Semantic Brief Pipeline"
        A[User Prompt Lengkap] --> B[Master Agent Holistic Parser]
        B --> C[Ekstraksi Outline & Kebutuhan Spesifik]
        C --> D[Kirim Full User Brief ke fetchSlideContentFromAI]
        D --> E[Master Design LLM Hasilkan Slide Akurat 100%]
    end

    subgraph "2. Fixed 16:9 Canvas & Transform Scaler"
        F[Slide Section 1200x675 Fixed] --> G[ResizeObserver Stage Viewport]
        G --> H[Hitung scale = min availW/1200, availH/675]
        H --> I[Apply CSS transform: scale]
        I --> J[Zero-Reflow & Vektor Proporsional 100%]
    end

    subgraph "3. Windows Cross-Platform PDF Engine"
        K[Request Export PDF] --> L{OS Windows / Linux?}
        L -->|Windows| M[Gunakan tempfile.gettempdir & cari chrome.exe / msedge.exe]
        L -->|RPC Gagal| N[Graceful Fallback: window.print dengan @page 1200x675]
        M --> O[Download PDF 16:9 Berhasil]
        N --> O
    end

    subgraph "4. Temporary Chat"
        P[Tombol Icon-Only di Header] --> Q[Toggle isTemporaryChatActive]
        Q -->|Aktif| R[Bypass saveCurrentSessionToDB & Visual Badge]
        Q -->|Nonaktif| S[Simpan Normal ke IndexedDB]
    end
```

---

## 📝 3. Rincian Perubahan Berkas (Proposed Changes)

### Komponen 1: Pemahaman Brief Lengkap di Mode Design
1. **[`extension/design/design_agent.js`](file:///home/arya/browser-agent/extension/design/design_agent.js)**:
   - Perbarui `createSlidePromptForMasterDesign` untuk menerima argumen `userBrief`.
   - Sertakan blok instruksi:
     ```
     BRIEF LENGKAP PENGGUNA:
     """
     ${userBrief}
     """
     TARGET SLIDE ${slideNum}: ${title}
     - Terapkan poin-poin spesifik dari brief pengguna di atas ke dalam slide ini.
     ```
2. **[`extension/design/design_executor.js`](file:///home/arya/browser-agent/extension/design/design_executor.js)**:
   - Teruskan `userMessage` utuh ke `fetchSlideContentFromAI` (tidak hanya `cleanTopic` yang terpotong).
   - Tambahkan fungsi ekstraksi outline pengguna: jika pengguna menulis "Slide 1: ... Slide 2: ...", jadikan daftar tersebut sebagai cetak biru slide.

---

### Komponen 2: Fixed 16:9 Virtual Canvas & Viewport Transform Scaler
1. **[`extension/design/slide_styles.js`](file:///home/arya/browser-agent/extension/design/slide_styles.js)**:
   - Kunci `.slide-section` pada ukuran tetap:
     ```css
     @media screen {
       .slide-section {
         display: none !important;
         width: 1200px !important;
         height: 675px !important;
         min-width: 1200px !important;
         min-height: 675px !important;
         max-width: 1200px !important;
         max-height: 675px !important;
         opacity: 0;
         transform-origin: center center;
         transition: opacity 0.2s ease;
       }
       .slide-section.active {
         display: flex !important;
         opacity: 1 !important;
       }
     }
     ```
2. **[`extension/design/slide_deck_engine.js`](file:///home/arya/browser-agent/extension/design/slide_deck_engine.js)**:
   - Pasang fungsi `initSlideDeckAutoscale()` di dalam `getSlideDeckRuntimeScript()`:
     Mengukur `stage.clientWidth` dan `stage.clientHeight`, menghitung faktor skala `Math.min(availW / 1200, availH / 675)`, dan menerapkan `transform: scale(...)` ke slide aktif.

---

### Komponen 3: Perbaikan Ekspor PDF di Windows
1. **[`host/native_host.py`](file:///home/arya/browser-agent/host/native_host.py)**:
   - Ganti hardcoded `/tmp/` dengan `tempfile.gettempdir()`.
   - Tambahkan path Windows untuk Google Chrome dan Microsoft Edge:
     - `C:\Program Files\Google\Chrome\Application\chrome.exe`
     - `C:\Program Files (x86)\Google\Chrome\Application\chrome.exe`
     - `%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe`
     - `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`
     - `C:\Program Files\Microsoft\Edge\Application\msedge.exe`
     - `shutil.which("chrome.exe")`, `shutil.which("msedge.exe")`
2. **[`extension/design/canvas_exporter.js`](file:///home/arya/browser-agent/extension/design/canvas_exporter.js)**:
   - Jika RPC native host gagal atau timeout, otomatis fallback ke dialog cetak `window.print()` (yang sudah diatur oleh `@media print` untuk ukuran 1200x675 px), sehingga pengguna di Windows tetap bisa menyimpan PDF tanpa pesan error putus.

---

### Komponen 4: Fitur Temporary Chat (Icon Only di Header Home)
1. **[`extension/newtab.html`](file:///home/arya/browser-agent/extension/newtab.html)**:
   - Di dalam `.header-right` (setelah `chip-system-tab`), tambahkan tombol icon-only:
     ```html
     <button type="button" class="btn-header-icon" id="btn-temporary-chat" title="Temporary Chat (Obrolan Sementara - Tidak Disimpan)" aria-label="Temporary Chat">
       <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
         <circle cx="12" cy="10" r="1.5" fill="currentColor"/>
       </svg>
       <span class="temporary-chat-indicator" id="temp-chat-dot"></span>
     </button>
     ```
2. **[`extension/sidepanel.html`](file:///home/arya/browser-agent/extension/sidepanel.html)**:
   - Tambahkan tombol yang sama pada bar status atas agar konsisten di semua tampilan.
3. **[`extension/sidepanel.js`](file:///home/arya/browser-agent/extension/sidepanel.js)**:
   - Variabel state: `let isTemporaryChatActive = false;`
   - Event listener klik tombol: toggle status `isTemporaryChatActive`, ubah class tombol `.active`, dan tampilkan toast notifikasi.
   - Proteksi penyimpanan:
     - Di fungsi `saveCurrentSessionToDB()`, tambahkan pengecekan `if (isTemporaryChatActive) return;`.
     - Ketika Temporary Chat aktif, percakapan tidak dimasukkan ke database riwayat IndexedDB dan tidak dibuatkan entri sesi di sidebar.
4. **CSS (`extension/newtab.css` & `sidepanel.css`)**:
   - Styling tombol `.btn-header-icon` dengan visual glassmorphic modern (radius rounded, hover glow, active indicator ring).

---

## 🧪 4. Rencana Pengujian (Verification Plan)

### Automated Tests
1. Uji sintaksis JavaScript:
   ```bash
   node -c extension/design/*.js extension/sidepanel.js extension/options.js
   ```
2. Pastikan kepatuhan aturan Sub-800 baris tetap terjaga:
   ```bash
   wc -l extension/design/*.js extension/apps-integration/*.js
   ```
3. Validasi skrip Python:
   ```bash
   python3 -m py_compile host/native_host.py
   ```

### Manual Verification
1. **Verifikasi Pemahaman Brief di Mode Design:**
   - Kirim prompt brief lengkap: *"Buatkan 4 slide presentasi tentang strategi ekspansi UMKM Kopi Malang ke Sydney: Slide 1 cover, Slide 2 riset pasar specialty coffee, Slide 3 sertifikasi ekspor, Slide 4 proyeksi omset 2026."*
   - Verifikasi Slide 1 s/d 4 memuat konten spesifik sesuai arahan (tidak ngawur/generik).
2. **Verifikasi Zooming Fixed 16:9 Canvas:**
   - Buka slide deck di Canvas.
   - Lakukan browser zoom ke 150%, 175%, 75%, 50%.
   - Pastikan slide tetap terkunci pada rasio 16:9 dan seluruh elemen membesar/mengecil proporsional tanpa ada teks terpotong atau kartu meluap.
3. **Verifikasi Ekspor PDF Cross-Platform:**
   - Klik Export -> PDF slide deck.
   - Pastikan proses ekspor menghasilkan file PDF tanpa pesan error.
4. **Verifikasi Tombol Temporary Chat:**
   - Buka halaman Home Newtab.
   - Periksa keberadaan tombol Temporary Chat (icon only) di pojok kanan header.
   - Klik tombol: pastikan toggle aktif, kirim pesan, lalu buka tab riwayat untuk memastikan percakapan sementara tersebut tidak disimpan ke riwayat.
