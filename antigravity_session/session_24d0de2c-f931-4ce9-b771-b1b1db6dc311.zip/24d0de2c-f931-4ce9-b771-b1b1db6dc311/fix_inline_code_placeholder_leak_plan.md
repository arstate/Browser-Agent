# Implementation Plan: Fix Inline Code & Placeholder Leak (`🪟INLINE_CODE21≡`)

## Goal Description
Memperbaiki bug rendering pada Markdown parser Browser Agent (`sidepanel.js`) di mana potongan teks inline code (backtick) yang bersebelahan atau sebaris dengan simbol matematika / LaTeX (seperti `\rightarrow`, `\to`, atau formula `$..$`) bocor ke tampilan chat pengguna dalam bentuk token mentah bertuliskan:
`🪟INLINE_CODE21≡ → ≡INLINE_CODE22≡, dan 🪟INLINE_CODE23≡ → ≡INLINE_CODE24≡`

### Akar Penyebab Masalah (Root Cause):
1. **Placeholder Bertanda Underscore (`_`)**:
   Saat mem-parsing markdown di `formatMarkdown()`, inline code disimpan sementara sebagai:
   `\uE000INLINE_CODE_${inlineCodes.length}\uE001`.
2. **Tabrakan Regex Subscript LaTeX**:
   Ketika baris teks mengandung simbol LaTeX (seperti `\rightarrow`), fungsi `parseLatexMath()` mengeksekusi konversi matematika. Di dalamnya, regex subscript LaTeX:
   `s.replace(/_{([^}]+)}|_([0-9a-zA-Z\+\-]+)/g, (m, p1, p2) => '<sub>' + (p1 || p2) + '</sub>')`
   secara keliru mencocokkan kata `_CODE` dan `_21` di dalam string placeholder itu sendiri!
   - `\uE000INLINE_CODE_21\uE001` bermutasi menjadi `\uE000INLINE<sub>CODE</sub><sub>21</sub>\uE001`.
3. **Kegagalan Restorasi (Split-Join Miss)**:
   Pada tahap akhir restorasi kode:
   `finalHtml.split('\uE000INLINE_CODE_21\uE001').join(...)`
   pencarian gagal total karena placeholder aslinya sudah berubah menjadi tag `<sub>`. Akibatnya, token rusak tersebut ditampilkan apa adanya ke layar user, di mana karakter Private Use Area `\uE000` & `\uE001` dirender oleh sistem sebagai glyph kotak tofu (`🪟` / `≡`) dengan teks subscript `CODE` dan `21`.

---

## User Review Required
> [!IMPORTANT]
> Perbaikan ini murni pada frontend Markdown Parser (`sidepanel.js`) tanpa mengubah struktur database chat. Riwayat chat lama yang memuat pesan ini akan langsung otomatis ter-render rapi dan normal seketika setelah ekstensi direload.

> [!NOTE]
> Tidak ada breaking change terhadap fitur markdown lain (tabel, latex math block, handle pills `@mention`, color swatches `#hex`, file cards, maupun code blocks).

---

## Open Questions
Tidak ada pertanyaan terbuka. Masalah, akar penyebab, dan solusinya sudah teridentifikasi secara deterministik 100% melalui reproduksi node test script.

---

## Proposed Changes

### Frontend Extension (`extension/sidepanel.js`)

#### [MODIFY] `sidepanel.js`

1. **Ganti Format Semua Placeholder Menjadi Collision-Free Tanpa Underscore**:
   - `\uE000INLINECODE${inlineCodes.length}\uE001` (sebelumnya `\uE000INLINE_CODE_...`)
   - `\uE000CODEBLOCK${codeBlocks.length}\uE001` (sebelumnya `\uE000CODE_BLOCK_...`)
   - `\uE000TABLEBLOCK${tableBlocks.length}\uE001` (sebelumnya `\uE000TABLE_BLOCK_...`)
   - `\uE000IMAGEBLOCK${imageBlocks.length}\uE001` (sebelumnya `\uE000IMAGE_BLOCK_...`)
   - `\uE000FILECARD${fileCardBlocks.length}\uE001` (sebelumnya `\uE000FILE_CARD_...`)
   Dengan meniadakan karakter underscore `_`, placeholder menjadi kebal terhadap regex bold `__`, italic `_`, maupun LaTeX subscript `_`.

2. **Isolasi Subscript LaTeX ke Dalam Konteks Matematika Saja**:
   - Di fungsi `parseLatexMath()`:
     Pastikan konversi subscript `_([0-9a-zA-Z\+\-]+)` dan superscript `\^...` hanya berlaku di dalam blok formula matematika yang sah (`$...$`, `\(...\)`, `$$...$$`).
   - Pada langkah 4 (standalone symbols luar dollar), batasi hanya pada simbol LaTeX spesifik (misal `\to`, `\rightarrow`, `\ge`, `\le`, `\times`), dan **JANGAN** menjalankan penggantian global underscore ke `<sub>` di teks polos non-matematika agar tidak merusak nama variabel seperti `snake_case_name`.

3. **Placeholder Shielding & Sanitizer Fallback**:
   - Lindungi setiap string token `\uE000[^\uE001]+\uE001` agar dilewati oleh `convertMathTokens()`.
   - Pada tahap restorasi akhir, jika ada placeholder yang tersisa akibat anomali, pasang fail-safe regex sanitizer agar karakter PUA (`\uE000` & `\uE001`) tidak pernah bocor ke tampilan user.

4. **Bump Versi Ekstensi**:
   - Update versi ke `v2.150.277` di `extension/manifest.json`.

---

## Verification Plan

### Automated Tests
1. **Node.js Parser Unit Test**:
   Jalankan script pengujian khusus di Node.js menggunakan pesan teks riil dari kasus user:
   `* *Halaman 9 poin 3 & 4:* Ubah `Puri (2025)` $\rightarrow$ `(2024)`, dan `Abdurrahman (2025)` $\rightarrow$ `Irfan (2022)`.*`
   - Pastikan output menghasilkan 4 tag `<code class="md-inline-code">` yang sempurna.
   - Pastikan tidak ada karakter `\uE000`, `\uE001`, `INLINE_CODE`, maupun tag `<sub>` yang salah sasaran.
2. **Syntax & Sub-800 Line Validation**:
   - `node -c extension/sidepanel.js`
   - Verifikasi batas baris file modular tetap teratur.

### Manual Verification
1. Buka sesi chat yang memuat pesan "Bab II Halaman 9 poin 3 & 4" di Chrome Sidepanel.
2. Pastikan teks:
   `Ubah Puri (2025) → (2024), dan Abdurrahman (2025) → Irfan (2022).`
   tampil rapi dengan badge kode abu-abu/gelap yang estetik dan panah `→` yang bersih, tanpa ada lagi kotak `🪟INLINE_CODE21≡`.
