# 🎯 ARSITEKTUR & RENCANA IMPLEMENTASI: AUTONOMOUS SELF-EVALUATING & CRITIC ENGINE

Dokumen ini menjawab secara tuntas dan merancang arsitektur bagaimana **Browser Agent** dapat secara mandiri mengetahui apakah jawabannya **sudah benar atau belum**, serta otomatis bekerja lagi melakukan iterasi koreksi mandiri hingga hasilnya 100% akurat.

---

## 💡 1. JAWABAN INTI: APAKAH BISA?

> **BISA BANGET, 100% BISA!** 
> Fitur ini adalah standar tertinggi dalam AI Agent modern (dikenal sebagai **Evaluator-Optimizer Loop** atau **Actor-Critic Pattern** yang digunakan sistem AI tercanggih seperti AlphaCode dan DeepSeek-R1).

### Mengapa AI Biasa Sering Gagal Mengetahui Kesalahannya Sendiri?
Secara biologis/matematis, model LLM tunggal adalah *next-token predictor*. Jika model disuruh menilai jawabannya sendiri secara langsung tanpa acuan (*"Apakah jawabanmu tadi benar?"*), ia cenderung mengalami **Self-Bias & Sycophancy** (mengira dirinya selalu benar, atau malah panik dan mengubah jawaban yang benar jadi salah).

**Agar AI bisa tahu jawabannya belum benar secara akurat, sistem butuh "Cermin Penguji" (Objective Evaluation Layer).**

---

## 🏛️ 2. EMPAT METODE EVALUASI AGAR AI TAHU JAWABANNYA BELUM BENAR

```mermaid
graph TD
    A[User Request] --> B[Step 1: Actor/Worker Agent Menghasilkan Solusi / Data]
    B --> C{Objective Evaluation Layer / Critic Engine}
    C -->|Kriteria 1: Deterministic Check| D[Eksekusi Tool / Cek Error / Cek Format]
    C -->|Kriteria 2: Contract Checklist| E[Cek Kelengkapan Permintaan User]
    C -->|Kriteria 3: Source Ground-Truth| F[Kroscek Fakta ke Dokumen / Halaman Web]
    
    D & E & F --> G{Apakah Lolos 100%?}
    G -- LOLOS (Akurat & Lengkap) --> H[🎯 Finalisasi Jawaban & Tampilkan ke User]
    G -- TIDAK LOLOS (Ada Kekurangan) --> I[Penyusunan Feedback Spesifik / Targeted Guidance]
    I --> J[Agent Bekerja Lagi Memperbaiki Bagian yang Kurang]
    J --> B
```

### 1. Deterministic & Programmatic Verification (Uji Eksekusi Nyata)
Ini adalah verifikasi paling solid dan 0% halusinasi:
- **Kasus Koding / Script:** Script yang dibuat langsung dijalankan di terminal sandbox. Jika `exit code !== 0` atau syntax error, agent **tahu 100% kodenya salah** dan langsung membaca traceback error untuk memperbaikinya.
- **Kasus Data / Scraping:** Jika user minta data dari 20 halaman dokumen, sistem menghitung apakah output mencakup 20 halaman. Jika sistem mendeteksi hanya 2 halaman yang terambil, sistem langsung menolak output tersebut dan memerintahkan agent mengambil sisa 18 halaman.
- **Kasus Link / URL:** Sistem memvalidasi apakah tautan/link yang diberikan agent benar-benar aktif (HTTP 200) atau 404 broken link.

### 2. Contract Constraint Checklist (Pemeriksa Kontrak Permintaan)
Sebelum mulai bekerja, sistem menyusun **Daftar Kriteria Sukses (Success Rubric)** dari prompt pengguna:
*Contoh:* User meminta: *"Buatkan 5 rekomendasi rumah di Sidoarjo dengan rincian DP, angsuran per bulan, dan jarak ke bandara."*
- Evaluator memeriksa output:
  - [x] Ada 5 rekomendasi rumah?
  - [x] Ada rincian DP?
  - [x] Ada angsuran per bulan?
  - [ ] Ada jarak ke bandara? ❌ *(Kurang di rumah nomor 3 dan 4)*
- Karena kriteria belum 100%, sistem otomatis menginstruksikan agent:
  > *"Rekomendasi sudah bagus, tetapi data jarak ke bandara untuk unit 3 dan 4 masih belum tercantum. Lengkapi kedua data tersebut sekarang."*
- Agen bekerja lagi secara **terarah (targeted)** tanpa merusak data yang sudah benar.

### 3. Source Ground-Truth Cross-Check (Validasi Fakta Dokumen)
- Saat menganalisis dokumen (PDF/Proposal) atau website, sistem membandingkan klaim agent dengan data hasil ekstraksi mentah (`doc_parser` / DOM snapshot).
- Jika ada klaim angka/nama yang tidak memiliki bukti kutipan (unsupported hallucination), sistem menandai bagian tersebut untuk diinspeksi ulang via `inspect_page_detail`.

### 4. Actor-Critic Multi-Agent Pattern (Sistem Dua Otak)
- **Agent A (Worker / Generator):** Berfokus menyusun draft solusi terbaik.
- **Agent B (Critic / Auditor):** Bertindak sebagai penguji kritis independen yang mencari celah, kesalahan logika, atau inkonsistensi.

---

## ⚖️ 3. BEDA ANTARA "OVERTHINKING ERROR" DENGAN "SELF-CORRECTION CERDAS"

| Aspek | Overthinking Error (Bug Sebelumnya) | Smart Self-Correction (Sistem Baru) |
|---|---|---|
| **Pemicu Iterasi** | Checklist milestone kaku buatan sistem (`hasPendingMilestones`) | Bukti objektif bahwa data kurang, salah, atau ada error |
| **Instruksi ke AI** | Bentakan buta: *"Tugas belum selesai! Dilarang berhenti!"* | Arahan presisi: *"Data bab 4 belum ada, lengkapi bab 4"* |
| **Dampak ke Jawaban** | Meragukan diri sendiri, halusinasi, merusak teks benar | Menjaga teks benar dan hanya menyempurnakan kekurangannya |
| **Kapan Berhenti?** | Terjebak looping sampai batas max steps | Langsung berhenti begitu kriteria terpenuhi (Early-Exit) |

---

## 🏗️ 4. RANCANGAN IMPLEMENTASI DI BROWSER AGENT

Kita dapat mengintegrasikan komponen baru: **`extension/core/semantic_critic_engine.js`** dan memperluas **`SelfCorrectionEngine`**:

### A. Komponen 1: `SemanticCriticEngine.evaluateResponse()`
Mengevaluasi draft respon teks terhadap kriteria prompt user sebelum ditampilkan final ke pengguna:
```javascript
function evaluateResponseQuality(userPrompt, assistantDraft, executionContext) {
  // 1. Cek Kekosongan atau Jawaban Mengambang
  if (isVagueOrCopOut(assistantDraft)) {
    return { passed: false, reason: "Jawaban terlalu mengambang/mengelak." };
  }
  
  // 2. Cek Ketuntasan Tool yang Tertunda
  if (executionContext.lastToolFailed && !assistantDraft.includes("koreksi")) {
    return { passed: false, reason: "Ada tool yang gagal dieksekusi tetapi belum ditangani." };
  }

  // 3. Cek Format/Kontrak Khusus (misal: jumlah item, tabel, atau file output)
  const missingRequirements = checkMissingRequirements(userPrompt, assistantDraft);
  if (missingRequirements.length > 0) {
    return { 
      passed: false, 
      reason: `Kekurangan kriteria: ${missingRequirements.join(', ')}`,
      actionableGuidance: `Lengkapi poin berikut: ${missingRequirements.join('; ')}`
    };
  }

  return { passed: true };
}
```

### B. Komponen 2: Safe Correction Loop dengan Strict Circuit-Breaker
- Maksimal iterasi koreksi mandiri dibatasi **maksimal 2 kali (Max 2 Self-Refine turns)**.
- Jika setelah 2 kali perbaikan masih belum sempurna, sistem tetap mengembalikan hasil terbaik yang didapat dan secara jujur memberitahu pengguna bagian mana yang belum berhasil diverifikasi (transparansi 100%, anti-halusinasi).

---

## 🚀 5. RENCANA TAHAPAN EKSEKUSI (JIKA INGIN DITERAPKAN)

1. **Tahap 1 (Fundamental - Anti-Overthinking):**
   - Pasang perbaikan **Early-Exit** dari plan sebelumnya agar AI tidak looping saat jawaban sudah benar.
2. **Tahap 2 (Self-Evaluating Critic Engine):**
   - Buat `extension/core/semantic_critic_engine.js`.
   - Hubungkan ke `sidepanel.js` dan `background.js` untuk mengevaluasi jawaban akhir sebelum di-render.
3. **Tahap 3 (Pengujian Skenario Nyata):**
   - Uji kasus data kurang (AI otomatis melengkapi).
   - Uji kasus data sudah lengkap (AI langsung berhenti tuntas).
