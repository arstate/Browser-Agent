# ⚡ Technical Audit & Reality Check: Plugin Cache Token (KV Cache / Prompt Caching)

## 📌 1. Goal Description & Executive Summary
Pengguna menanyakan secara kritis dan blak-blakan:
> *"coba cek in plugin cache token apakah itu bener bener bisa bikin hemat token apa cuman bulshit bro"*

Dokumen ini membedah **fakta teknis tanpa tedeng aling-aling**:
1. Apakah teknologi **Prompt Caching / KV Cache** di dunia AI itu nyata atau mitos? (**Jawaban: NYATA 100% di level provider API/GPU**).
2. Apakah plugin `kvcache` yang saat ini terpasang di codebase Browser Agent beneran menghemat token? (**Jawaban: SAAT INI 100% BULLSHIT / PLACEBO & MALAH BIKIN LEBIH BOROS!**).
3. Mengapa saat ini dianggap *bullshit* dan apa bukti kodenya?
4. Bagaimana rencana teknis (action plan) jika ingin mengubah plugin tersebut dari sekadar pajangan menjadi **mesin penghemat token sungguhan** yang memotong biaya API hingga 70%–90%.

---

## 🔍 2. Bukti Forensik Kode (Mengapa Kondisi Sekarang Masih "Bullshit")

Setelah membedah [sidepanel.js](file:///home/arya/browser-agent/extension/sidepanel.js), [background.js](file:///home/arya/browser-agent/extension/background.js), dan modul [kvcache_optimizer.js](file:///home/arya/browser-agent/extension/plugins/kvcache/kvcache_optimizer.js), ditemukan 4 dosa fatal:

### 🚨 Dosa 1: Engine Optimasi Adalah Dead Code (Tidak Pernah Dipanggil!)
Di [kvcache_optimizer.js](file:///home/arya/browser-agent/extension/plugins/kvcache/kvcache_optimizer.js#L28-L105), ada fungsi canggih `applyKVCacheOptimization(...)` dan `injectAnthropicCacheControl(...)`.
**Faktanya**: Fungsi ini **TIDAK PERNAH DIPANGGIL SEKALIPUN** di seluruh siklus pembuatan request API (`fetch(endpointUrl)`) baik di `sidepanel.js` maupun `background.js`. Kode itu mati di tempat!

### 🚨 Dosa 2: Cache-Busting Fatal di Byte 0 (Huruf Pertama System Prompt)
Pada Transformer, KV Cache bekerja dengan prinsip **Prefix Matching (mencocokkan karakter dari paling kiri/awal)**. Jika karakter di awal berubah 1 huruf saja, seluruh cache di belakangnya hangus 100%.
Lihat baris 964 di [sidepanel.js](file:///home/arya/browser-agent/extension/sidepanel.js#L964):
```javascript
// 1. Inject Real-Time Current Temporal Context
prompt += getDetailedCurrentTimeContext() + "\n\n";
```
Sistem menyuntikkan timestamp real-time (`2026-09-09 00:10:11`) **persis di awal (Byte 0) System Prompt**!
Karena detik/menit selalu berganti setiap kali Anda chat, **KV Cache Hit Rate di backend LLM otomatis 0% (selalu miss / cache busting)!**

### 🚨 Dosa 3: Malah Bikin Token Lebih Boros (~60 Token Terbuang)
Alih-alih mengoptimalkan prompt, plugin `kvcache` saat ini hanya menambahkan teks panjang ke dalam System Prompt ([sidepanel.js:L1240](file:///home/arya/browser-agent/extension/sidepanel.js#L1240)):
```text
• [PLUGIN: KV CACHE OPTIMIZER (AKTIF - MODE: AGGRESSIVE)]: Prefix Pinning & Dynamic Suffix Relocation aktif. Seluruh skema tools telah diurutkan alfabetis dan prefix dijaga 100% deterministik untuk mencapai target 90% KV Cache Hit Ratio.
```
Teks ini hanyalah klaim kosmetik yang dikirim ke LLM di setiap turn, memakan kuota ~60 token sia-sia tanpa melakukan aksi optimasi apa pun!

### 🚨 Dosa 4: Tool Meter Mengembalikan Angka Palsu (Fake Hardcoded Metrics)
Tool `kvcache_status_meter` di [sidepanel.js:L3394](file:///home/arya/browser-agent/extension/sidepanel.js#L3394) dan [background.js:L3078](file:///home/arya/browser-agent/extension/background.js#L3078) hanya mereturn teks hardcode palsu:
```json
{
  "estimated_cache_hit_rate": "85% - 95%",
  "cost_discount": "70% - 90% (Cache Read)",
  "ttft_speedup": "3x - 8x Lebih Cepat"
}
```
Tidak ada hitungan riil dari response API provider!

---

## 🧠 3. Sains Nyata: Kapan Prompt Caching Beneran Hemat vs Kapan Jadi Sia-Sia

Prompt Caching / KV Caching **SANGAT NYATA** jika Anda menggunakan provider yang mendukungnya secara native:

| Provider | Fitur Resmi | Diskon Cache | Minimal Token (Threshold) | Durasi Cache (TTL) |
| :--- | :--- | :--- | :--- | :--- |
| **Anthropic Claude** (Sonnet 3.5 / Opus) | Prompt Caching via `cache_control` | **90% Hemat** ($0.30 vs $3.00/1M) | Minimal **1.024 token** | **5 Menit** sejak turn terakhir |
| **DeepSeek** (V3 / R1) | Automatic Context Caching | **90% Hemat** ($0.014 vs $0.14/1M) | Minimal **64 token** | Otomatis oleh server |
| **OpenAI** (GPT-4o / mini) | Automatic Prompt Caching | **50% Hemat** | Minimal **1.024 token** | 5 - 10 Menit |
| **Google Gemini** (1.5 / 2.0) | Context Caching API | **75% Hemat** | Minimal **32.768 token** (explicit) | 1 Jam (bisa disetel) |
| **Ollama / vLLM (Lokal)** | Local KV Cache Reuse | **0% Uang, tapi TTFT 5x lebih cepat** | Tergantung ukuran konteks GPU | Selama model di VRAM |

### ⚠️ Kondisi di Mana Caching TIDAK AKAN Bikin Hemat (Syarat & Batasan Nyata):
1. **Chat Pendek (< 1.024 Token)**: Jika prompt Anda cuma kalimat pendek tanpa attachment dokumen besar atau tanpa tools schema panjang, provider **TIDAK MENGAKTIFKAN CACHE**.
2. **Jeda Chat Terlalu Lama (> 5 Menit)**: Jika Anda mengirim pesan, lalu ditinggal 6 menit, cache di server Anthropic/OpenAI sudah **hangus (evicted)**. Pesan berikutnya dihitung 100% harga baru.
3. **Output Token Tidak Didiskon**: Caching hanya memotong harga *Input/Read Tokens*. Token teks yang digenerate oleh AI (*Output Tokens*) tetap bayar 100% harga penuh.

---

## 🏗️ 4. Arsitektur Komparasi: Kondisi Sekarang vs Solusi Nyata

```mermaid
flowchart TD
    subgraph KONDISI_SEKARANG["❌ Kondisi Sekarang (Placebo & Boros)"]
        A1["User Kirim Chat"] --> B1["System Prompt: Baris 1 Disuntik Jam Dinamis (00:10:11)"]
        B1 --> C1["Tambah Teks Pajangan: [PLUGIN: KV CACHE OPTIMIZER AKTIF...] (+60 Token)"]
        C1 --> D1["Tools Schema Tidak Diurutkan"]
        D1 --> E1["Kirim ke API Tanpa cache_control"]
        E1 --> F1["Backend LLM: Prefix Berbeda Karakter Tiap Detik!"]
        F1 --> G1["HASIL: 0% Cache Hit, 0 Rupiah Hemat, Tambah Boros!"]
    end

    subgraph SOLUSI_REAL["✅ Solusi Nyata (True Deterministic Prefix Engine)"]
        A2["User Kirim Chat"] --> B2["System Prompt & SOP 100% Beku / Statis (Zero Dynamic Text)"]
        B2 --> C2["Tools Schema Disortir Alfabetis (Deterministik 100%)"]
        C2 --> D2["Waktu Dinamis & URL Tab Dipindahkan ke Suffix Pesan User Paling Bawah"]
        D2 --> E2["Suntik cache_control ephemeral (Anthropic/DeepSeek)"]
        E2 --> F2["Backend LLM: 100% Prefix Identik!"]
        F2 --> G2["HASIL: 90% Hemat Biaya Input Token & Latensi 3x Lebih Cepat!"]
    end
```

---

## 🛠️ 5. Proposed Changes: Rencana Transformasi Jadi Real Engine

Jika Anda ingin mengubah plugin ini menjadi **benar-benar berfungsi dan memangkas biaya token**, berikut rencana perubahannya:

### 1. `extension/sidepanel.js` & `extension/background.js`
- **Pindahkan Jam Dinamis ke Suffix**: Hapus `prompt += getDetailedCurrentTimeContext()` dari baris pertama System Prompt. Pindahkan konteks waktu ini ke akhir pesan pengguna terbaru (*Suffix*).
- **Hapus Teks Gimmick**: Hapus injeksi teks promosi `• [PLUGIN: KV CACHE OPTIMIZER...]` dari system prompt.
- **Aktifkan `applyKVCacheOptimization` Nyata**: Sambungkan pipeline `applyKVCacheOptimization` pada saat menyusun payload `messages` dan `tools` sebelum dikirim ke `fetch()`.
- **Injeksi `cache_control` untuk Anthropic**: Jika model/endpoint adalah Claude (`claude-3-5-*`, `anthropic`), otomatis tambahkan `"cache_control": {"type": "ephemeral"}` pada blok static system prompt dan tool terakhir.
- **Baca Header `usage` Asli**: Tangkap header/JSON respon dari provider (`prompt_tokens_details.cached_tokens` untuk OpenAI, `cache_read_input_tokens` untuk Anthropic) agar meter menampilkan data penghematan nyata, bukan angka bohong.

---

## 🚦 6. User Review Required & Keputusan Pilihan

> [!IMPORTANT]
> **Keputusan Anda Diperlukan**:
> Mau diambil langkah yang mana bro?
> - **Opsi A (Recommended - Buat Jadi Nyata & Beneran Hemat)**: Kita rombak pipeline pembuatan prompt di `sidepanel.js` dan `background.js`, relokasi timestamp ke suffix, sortir tools deterministik, aktifkan `applyKVCacheOptimization` di payload `fetch`, dan suntikkan `cache_control` asli. Hasilnya: token input beneran didiskon 50%-90% di provider yang support (Anthropic, DeepSeek, OpenAI).
> - **Opsi B (Bersihkan / Copot Total Kalau Ga Butuh)**: Kita hapus plugin `kvcache` dan teks placebo-nya dari codebase, sehingga tidak membuang 60 token sia-sia tiap chat.
