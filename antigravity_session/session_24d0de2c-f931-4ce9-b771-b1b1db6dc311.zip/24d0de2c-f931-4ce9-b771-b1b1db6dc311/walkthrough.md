# 🚀 Walkthrough: Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing (v2.150.288)

## 📌 Ringkasan Masalah & Sasaran
Sebelumnya, ketika pengguna meminta evaluasi dokumen magang/proposal (misalnya *"coba cek proposal magang saya"* atau melampirkan berkas `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf`), sistem auto-agent secara keliru memilih agen komersial **Tiar Property - Meta Ads Auditor**.

### 🔍 Akar Masalah Teknis
1. **Kebocoran Kata Kerja Generik**: Kata kerja umum seperti `cek`, `lihat`, `periksa`, `analisis` sebelumnya tercakup di dalam `isAuditQuery`, yang secara otomatis mengaktifkan `isAdsQuery = (isAdsQuery || isAuditQuery)`. Akibatnya, setiap kalimat dengan kata "cek" langsung dicap sebagai query Meta Ads.
2. **Bias Kata Nama Agent Auditor**: Agen `Tiar Property - Meta Ads Auditor` memiliki kata kunci `auditor` di namanya sehingga langsung dihadiahi skor +35 saat kata `cek` muncul.
3. **Kebutaan Terhadap Lampiran Berkas**: Fungsi seleksi agen `resolveAutoAgents(userMessage, explicitMentions)` sebelumnya tidak menerima parameter lampiran `attachments`.
4. **Pencemaran Lintas Domain**: Tidak ada diskualifikasi domain yang memisahkan ekosistem komersial perumahan Tiar Property dengan kebutuhan akademik/magang Kominfo.

---

## 🛠️ Solusi Rekayasa yang Diimplementasikan

### 1. Attachment-Aware Semantic Recruitment Pipeline (`extension/sidepanel.js`)
Fungsi `resolveAutoAgents` kini menerima berkas lampiran `attachments`:
```javascript
function resolveAutoAgents(userMessage = "", explicitMentionAgents = [], attachments = []) {
  // Ekstraksi nama berkas lampiran
  const attachmentNames = Array.isArray(attachments) ? attachments.map(a => a.name || a.filename || "").filter(Boolean) : [];
  const attachmentStr = attachmentNames.join(" ").toLowerCase();
  const combinedContext = (userMessage + " " + attachmentStr).toLowerCase();
  // ...
}
```

### 2. Domain Silo Isolation & Decoupling Kata Kerja Netral
- Kata kerja `cek`, `lihat`, `periksa`, `analisis` didecouple sepenuhnya dari detektor iklan. Domain Meta Ads kini hanya aktif untuk kata domain spesifik (`meta ads`, `iklan`, `cpr`, `boncos`, dll.).
- Saat domain akademik/magang terdeteksi (`isInternshipDomain`), seluruh agen real estate komersial (`Tiar Property`) **langsung didiskualifikasi (skor = 0)**:
```javascript
if (isInternshipDomain) {
  if (idLower.includes("arya") || nameLower.includes("arya") || idLower.includes("magang") || nameLower.includes("magang")) {
    score += 150;
  }
  // STRICT DOMAIN SILO ISOLATION:
  if (agentBrand === "tiar_property") {
    score = 0; // Diskualifikasi mutlak agen komersial real estate
  }
}
```

### 3. Pemetaan Brand & Sasaran Milestone (`extension/core/goal_tracker.js`)
- `detectBrand` memetakan istilah `proposal`, `magang`, `internship`, `kominfo`, `logbook`, `laporan akhir`, `arya` ke `bangga_surabaya`.
- `inferAgentForTask` menugaskan milestone peninjauan dokumen akademik ke `ARYA-MAGANG-KOMINFO`.

---

## 🧪 Hasil Pengujian Otomatis

Unit test otomatis dijalankan via simulasi Node.js dengan 5 skenario nyata:
```
[TEST 1] Query: "coba cek proposal magang saya"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 2] Query: "tolong periksa halaman 3" + Attachment: "PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 3] Query: "cek iklan fb yang boncos"
  Selected: Tiar Property - Meta Ads Auditor -> PASSED!

[TEST 4] Query: "berapa angsuran kpr rumah di sukodono dp 0%"
  Selected: Tiar Property - Sales Closer CS -> PASSED!

[TEST 5] Query: "bikin script python terminal linux"
  Selected: Coding & System Engineer -> PASSED!

==================================================
🎉 ALL 5 AUTO-AGENT ROUTING TESTS PASSED 100%!
==================================================
```

---

## 📦 Verifikasi Versi & Restore Point
- **Versi Rilis**: `v2.150.288`
- **Pembaruan Berkas**:
  - `extension/manifest.json`: Versi dinaikkan ke `2.150.288`.
  - `extension/sidepanel.js`: Implementasi Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing.
  - `extension/core/goal_tracker.js`: Pemetaan brand & agen milestone untuk ARYA-MAGANG-KOMINFO.
  - `dokumentasi.md`: Catatan 171 ditambahkan.
  - `design.md`: Bagian 64 ditambahkan.
  - `agent_histori_chat.md`: Iterasi 171 ditambahkan.
- **Kepatuhan Sub-800 Baris**: Seluruh 12 berkas di `extension/design/` dan `extension/apps-integration/` tetap patuh `<= 798` baris.

---

# ⚡ Walkthrough: True KV Cache & Prefix Pinning Optimizer Engine (v2.150.289)

## 📌 Masalah & Akar Penyebab
- **0% Cache Hit di Headroom Proxy & 9Router**: Dari 1.57 juta token yang diproses oleh proxy Headroom (port 8787), terjadi 0% cache read akibat `miss_attribution: prefix_change` pada setiap permintaan.
- **Root Cause**: `buildDynamicSystemPrompt` menyuntikkan timestamp lokal dinamis di baris pertama prompt (`getDetailedCurrentTimeContext()`), memutasi byte-byte awal setiap detik/menit.
- **Placebo String**: Teks plugin `• [PLUGIN: KV CACHE OPTIMIZER...]` membuang ~60 token tanpa fungsi teknis caching.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Prefix Pinning 100% Statis**: System Prompt dan array skema tools dijaga 100% beku tanpa variabel dinamis.
2. **Dynamic Suffix Relocation**: Seluruh variabel waktu lokal dan URL tab aktif dipindahkan ke **Suffix pesan user terakhir** (`=== 🕒 DYNAMIC EXECUTION CONTEXT (SUFFIX - ISOLATED FOR KV CACHE) ===`).
3. **Penyortiran Tools Deterministik**: Array tools disortir secara alfabetis berdasarkan `function.name`.
4. **Provider Cache Control Injection**: Menyuntikkan `cache_control: { type: "ephemeral" }` untuk Anthropic Claude, DeepSeek, dan Headroom Proxy.
5. **Multi-Turn Synchronization**: Pesan user yang telah disisipkan suffix disinkronkan ke `conversationHistory` / `conversationTurns`, menjamin turn lampau tetap 100% bit-exact di turn berikutnya.
6. **Eliminasi Placebo Bloat**: Menghapus teks placebo ~60 token dari `sidepanel.js` dan `background.js`.

---

# 🏛️ Walkthrough: Claude Fable & Claude Opus 5 3-Line Cognitive Distillation (v2.150.290)

## 📌 Masalah & Akar Penyebab
- **Token Inflation ~500 Token**: Plugin Claude Fable dan Claude Opus 5 sebelumnya menyuntikkan esai 500 token tentang struktur folder markdown Obsidian (`/profile.md`, `/topics/`, `/areas/`) yang tidak pernah dipakai.
- **XML Tag Placebo**: Tag `<antml:reasoning_effort>` diabaikan oleh backend Google/OpenAI di 9Router.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Distilasi 3-Baris Ringkas (~30 Token)**:
   - Direktif dikompresi menjadi 3 baris presisi tinggi:
     1. *Accountability Without Self-Abasement*: Langsung ke solusi teknis lugas. DILARANG minta maaf berlebihan atau bersikap submissive saat dikritik.
     2. *Direct Prose & Zero Fluff*: Langsung ke poin inti tanpa kalimat pembuka/penutup klise. DILARANG menarasikan memori ("Berdasarkan ingatan...").
     3. *Truth-Seeking & Anti-Sycophancy*: Utamakan kebenaran faktual di atas kepatuhan buta (anti-flattery). Berani berikan sanggahan konstruktif.
   - Menghemat ~470 token di setiap pesan.
2. **Penanaman ke Default Core System Prompt**:
   - Ditanamkan langsung ke `DEFAULT_SYSTEM_PROMPT` (Agent Mode), `CHAT_ONLY_SYSTEM_PROMPT` (Chat Mode), dan `systemInstruction` (Telegram Bot). Karakter tegas dan lugas aktif permanen.

---

# 🔘 Walkthrough: Pure Toggle Switches UI & Redundant Modal Elimination (v2.150.291)

## 📌 Masalah & Akar Penyebab
- **Pengaturan Placebo / Redundan**: Tombol "Settings" dan modal dialog pada 3 plugin (KV Cache Optimizer, Claude Fable 5, dan Claude Opus 5 Distill) berisi slider Reasoning Effort, selector Tier, dan checkbox taksonomi file Obsidian yang tidak lagi berguna pasca pemadatan direktif kognitif 3 baris (~30 token) dan penanganan prefix KV Cache otomatis.
- **Beban DOM Berlebih**: 3 modal overlay membebani `extension/options.html` dengan total ~387 baris HTML tak terpakai.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Penghapusan Tombol Settings pada Kartu Plugin (`extension/options.html`)**:
   - Menghapus tombol `btn-config-kvcache`, `btn-config-claude-fable`, dan `btn-config-claude-opus-5`.
   - Mengubah tampilan kartu menjadi minimalis murni dengan toggle switch On/Off dan status aktif/nonaktif yang jelas.
2. **Pembersihan 3 Modal Dialog Konfigurasi (`extension/options.html`)**:
   - Menghapus `#modal-plugin-kvcache`, `#modal-claude-fable-config`, dan `#modal-claude-opus-5-config`.
   - Mengurangi 387 baris kode HTML tak terpakai.
3. **Preservasi Fungsionalitas Storage & Null-Safety Guard**:
   - State On/Off tetap disimpan ke `chrome.storage.local` (`plugin_settings.kvcache.enabled`, `claude_fable.enabled`, `claude_opus_5.enabled`).
   - Seluruh script pengendali plugin tetap berjalan normal tanpa error berkat guard null-checking.
4. **Verifikasi & Standar Sub-800 Baris**:
   - Validasi sintaksis `node -c` lulus 100%.
   - Seluruh 12 berkas di `extension/design/` dan `extension/apps-integration/` tetap patuh ketat `<= 798` baris.

---

# 🎨 Walkthrough: Master Design Brief Precision, Fixed 16:9 Virtual Canvas Autoscale, Cross-Platform Windows PDF Export, & Temporary Chat (v2.150.292)

## 📌 Masalah & Akar Penyebab
1. **Brief Desain Hilang / Terpotong**: Pada mode Design Mode, `cleanPresentationTopic` memotong input string prompt menjadi hanya 45 karakter dan hanya menyisipkan judul topik generic tanpa instruksi bab/detail pengguna, menyebabkan AI berhalusinasi dan menghasilkan materi ngawur. Sementara pada Open Canvas revisi, prompt revisi diteruskan penuh sehingga AI paham.
2. **Slide Deck Responsive & Teks Pecah Saat Zoom**: Preview slide menggunakan CSS lebar relatif (`width: min(1200px, 100%, ...)`), sementara font dan margin statis. Saat browser di-zoom atau drawer menyempit, wadah mengecil tapi font tetap besar sehingga terjadi wrapping teks canggung dan overflow kartu keluar rasio 16:9.
3. **Error Ekspor PDF di Windows**: Native host Python `export_slide_deck_pdf` menulis file sementara ke hardcoded Unix path `/tmp/deck_{ts}.html` yang tidak ada di OS Windows (`FileNotFoundError: No such file or directory`), serta kurangnya path executable Chrome/Edge Windows.
4. **Fitur Temporary Chat**: Diperlukan tombol obrolan sementara (*icon only*) di navbar atas New Tab agar percakapan bersifat ephemeral tanpa tercatat ke IndexedDB riwayat obrolan.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Injeksi Brief Lengkap ke Prompt Master Design (`design_agent.js` & `design_executor.js`)**:
   - Menambahkan parameter `userBrief` ke `createSlidePromptForMasterDesign()` dan menyisipkan blok `BRIEF & INSTRUKSI LENGKAP PENGGUNA` ke prompt AI.
   - Menambahkan parser `extractCustomUserOutline()` pada `createDefaultBlueprint()` untuk membaca struktur bab kustom yang diberikan pengguna.
   - Meneruskan `userMessage` ke pemanggilan `fetchSlideContentFromAI()` untuk Slide 1 (Cover) dan slide konten lanjutan.
2. **Fixed Virtual 16:9 Canvas (1200x675 px) & Proportional CSS Transform Autoscale (`slide_styles.js` & `slide_deck_engine.js`)**:
   - Mengunci `.slide-section` pada ukuran tetap `width: 1200px !important; height: 675px !important; position: absolute; transform-origin: center center;`.
   - Mengimplementasikan `initSlideDeckAutoscale()` yang mengukur lebar/tinggi pembungkus panggung (`.deck-stage-wrap`) dan menyetel `transform: scale(Math.min(availW / 1200, availH / 675))` secara dinamis via `window.resize` dan `ResizeObserver`.
3. **Universal Cross-Platform PDF Rendering Host (`host/native_host.py`)**:
   - Menggunakan `tempfile.gettempdir()` dan `os.path.join()` untuk menyimpan file HTML sementara dan hasil render PDF.
   - Mendeteksi binary browser Google Chrome dan Microsoft Edge di Windows (`%ProgramFiles%\Google\Chrome`, `%LocalAppData%\Google\Chrome`, `%ProgramFiles(x86)%\Microsoft\Edge`, `chrome.exe`, `msedge.exe`).
4. **Fitur Temporary Chat Icon-Only (`newtab.html`, `newtab.css`, `sidepanel.css`, `sidepanel.js`)**:
   - Menambahkan tombol `#btn-temporary-chat` (ikon fedora hat + glasses) di navbar kanan New Tab di samping `#chip-system-tab`.
   - Menambahkan efek active glow amber pada `.btn-temporary-chat.active`.
   - Menerapkan bypass penyimpanan `if (isTemporaryChatActive) return;` di `saveCurrentSessionToDB()` dan `executeSaveCurrentSessionToDB()`.
5. **Verifikasi & Standar Sub-800 Baris**:
   - Validasi sintaksis `node -c extension/design/*.js extension/sidepanel.js` dan `python3 -m py_compile host/native_host.py` lulus 100%.
   - Seluruh 12 berkas modular di `extension/design/` dan `extension/apps-integration/` tetap patuh ketat `<= 798` baris.



