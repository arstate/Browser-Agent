# 🚀 Walkthrough: Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing (v2.150.288)

## 📌 Ringkasan Masalah & Sasaran
Sebelumnya, ketika pengguna meminta evaluasi dokumen magang/proposal (misalnya *"coba cek proposal magang saya"* atau melampirkan berkas `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf`), sistem auto-agent secara keliru memilih agen komersial **Tiar Property - Meta Ads Auditor**.

### 🔍 Akar Masalah Teknis
1. **Kebocoran Kata Kerja Generik**: Kata kerja umum seperti `cek`, `lihat`, `periksa`, `analisis` sebelumnya tercakup di dalam `isAuditQuery`, yang secara otomatis mengaktifkan `isAdsQuery = (isAdsQuery || isAuditQuery)`. Akibatnya, setiap kalimat dengan kata "cek" langsung dicap sebagai query Meta Ads.
2. **Bias Kata Nama Agent Auditor**: Agen `Tiar Property - Meta Ads Auditor` memiliki kata kunci `auditor` di namanya sehingga langsung dihadiahi skor +35 saat kata `cek` muncul.
3. **Kebutaan Terhadap Lampiran Berkas**: Fungsi seleksi agen `resolveAutoAgents(userMessage, explicitMentions)` sebelumnya tidak menerima parameter lampiran `attachments`.
4. **Pencemaran Lintas Domain**: Tidak ada diskualifikasi domain yang memisahkan ekosistem komersial perumahan Tiar Property dengan kebutuhan akademik/magang Kominfo.

---

## 🛠️ Solusi Rekayasa yang Diimplementasikan

### 1. Attachment-Aware Semantic Recruitment Pipeline (`extension/sidepanel.js`)
Fungsi `resolveAutoAgents` kini menerima berkas lampiran `attachments`:
```javascript
function resolveAutoAgents(userMessage = "", explicitMentionAgents = [], attachments = []) {
  // Ekstraksi nama berkas lampiran
  const attachmentNames = Array.isArray(attachments) ? attachments.map(a => a.name || a.filename || "").filter(Boolean) : [];
  const attachmentStr = attachmentNames.join(" ").toLowerCase();
  const combinedContext = (userMessage + " " + attachmentStr).toLowerCase();
  // ...
}
```

### 2. Domain Silo Isolation & Decoupling Kata Kerja Netral
- Kata kerja `cek`, `lihat`, `periksa`, `analisis` didecouple sepenuhnya dari detektor iklan. Domain Meta Ads kini hanya aktif untuk kata domain spesifik (`meta ads`, `iklan`, `cpr`, `boncos`, dll.).
- Saat domain akademik/magang terdeteksi (`isInternshipDomain`), seluruh agen real estate komersial (`Tiar Property`) **langsung didiskualifikasi (skor = 0)**:
```javascript
if (isInternshipDomain) {
  if (idLower.includes("arya") || nameLower.includes("arya") || idLower.includes("magang") || nameLower.includes("magang")) {
    score += 150;
  }
  // STRICT DOMAIN SILO ISOLATION:
  if (agentBrand === "tiar_property") {
    score = 0; // Diskualifikasi mutlak agen komersial real estate
  }
}
```

### 3. Pemetaan Brand & Sasaran Milestone (`extension/core/goal_tracker.js`)
- `detectBrand` memetakan istilah `proposal`, `magang`, `internship`, `kominfo`, `logbook`, `laporan akhir`, `arya` ke `bangga_surabaya`.
- `inferAgentForTask` menugaskan milestone peninjauan dokumen akademik ke `ARYA-MAGANG-KOMINFO`.

---

## 🧪 Hasil Pengujian Otomatis

Unit test otomatis dijalankan via simulasi Node.js dengan 5 skenario nyata:
```
[TEST 1] Query: "coba cek proposal magang saya"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 2] Query: "tolong periksa halaman 3" + Attachment: "PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 3] Query: "cek iklan fb yang boncos"
  Selected: Tiar Property - Meta Ads Auditor -> PASSED!

[TEST 4] Query: "berapa angsuran kpr rumah di sukodono dp 0%"
  Selected: Tiar Property - Sales Closer CS -> PASSED!

[TEST 5] Query: "bikin script python terminal linux"
  Selected: Coding & System Engineer -> PASSED!

==================================================
🎉 ALL 5 AUTO-AGENT ROUTING TESTS PASSED 100%!
==================================================
```

---

## 📦 Verifikasi Versi & Restore Point
- **Versi Rilis**: `v2.150.288`
- **Pembaruan Berkas**:
  - `extension/manifest.json`: Versi dinaikkan ke `2.150.288`.
  - `extension/sidepanel.js`: Implementasi Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing.
  - `extension/core/goal_tracker.js`: Pemetaan brand & agen milestone untuk ARYA-MAGANG-KOMINFO.
  - `dokumentasi.md`: Catatan 171 ditambahkan.
  - `design.md`: Bagian 64 ditambahkan.
  - `agent_histori_chat.md`: Iterasi 171 ditambahkan.
- **Kepatuhan Sub-800 Baris**: Seluruh 12 berkas di `extension/design/` dan `extension/apps-integration/` tetap patuh `<= 798` baris.
