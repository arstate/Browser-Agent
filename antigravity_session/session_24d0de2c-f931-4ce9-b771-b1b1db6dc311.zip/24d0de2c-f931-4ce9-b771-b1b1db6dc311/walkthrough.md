# Walkthrough: Eliminasi Halusinasi Pembuatan & Ghost Card Slide Deck PDF pada Permintaan Prompt Feed Carousel

Perbaikan komprehensif atas bug di mana sistem secara otomatis membuat/menempelkan kartu OpenDesign Presentation Slide Deck Widescreen 16:9 PDF saat pengguna meminta prompt gambar untuk Instagram Feed Carousel.

---

## 🔍 Akar Masalah yang Ditemukan (Root Causes)

1. **False-Positive Regex Pencocokan Kata `"slide"`**:
   - Di `runAgentLoop` dan `runChatModeLoop`:
     ```javascript
     const userAskedSlide = /(?:slide|deck|presentasi|presentation|powerpoint|ppt|kanvas|canvas)/i.test(userMessage || "");
     ```
   - Saat pengguna mengetik: *"prompt nya itu per slide feed"*, regex di atas bernilai **`true`** hanya karena ada kata `"slide"`, mengabaikan fakta bahwa pengguna sedang meminta konten postingan gambar feed Instagram.

2. **Ghost Slide Card Auto-Append**:
   - Di baris 7544 `runAgentLoop`:
     ```javascript
     if (activeSlideArt && activeSlideArt.html && (touchedSlideTool || userAskedSlide || assistantBubble?._activeDesignArtifact)) {
       renderOpenDesignCard(curContentEl, activeSlideArt, { isRevision: true });
     }
     ```
   - Jika pengguna sebelumnya pernah membuat/melihat slide deck di sesi chat tersebut, artefak `activeSlideArt` masih ada di memori.
   - Karena `userAskedSlide` bernilai `true` (akibat kata *"per slide feed"*), sistem **secara paksa menempelkan kartu slide deck lama** dengan badge `[Live Updated]`, padahal agen sama sekali TIDAK menjalankan tool `create_slide_deck_design` pada giliran tersebut!

3. **Pembajakan Routing & Injeksi Konteks Revisi (`isDeckRevision`)**:
   - Di `handleSendMessage` dan `runAgentLoop`, variabel `isDeckRevision` hanya memeriksa `canvasIsOpen && activeArt`.
   - Hal ini membuat setiap pesan yang diketik saat drawer terbuka disuntik arahan revisi slide (`[TARGET FILE REVISI: ...]`) dan berisiko dialihkan langsung ke `runDesignModeLoop`.

---

## 🛠️ Solusi Rekayasa yang Diterapkan

### 1. Trio Helper Disambiguasi Semantik Eksplisit
Ditambahkan pada `extension/sidepanel.js`:
- **`isSocialMediaOrImagePrompt(text)`**: Mendeteksi konteks media sosial dan generator gambar (`feed`, `carousel`, `instagram`, `ig`, `konten`, `postingan`, `midjourney`, `ideogram`, `flux`, `slide feed`, `feed slide`, `view depan`, `view dapur`).
- **`isExplicitSlideDeckIntent(text)`**: Hanya bernilai `true` jika pengguna secara eksplisit meminta presentasi/slide deck 16:9 dan **bukan** konten medsos.
- **`isSlideDeckRevisionInstruction(text)`**: Memvalidasi adanya kata kerja revisi nyata (`revisi`, `ubah`, `ganti`, `edit`, `tambah`, `pisah`, `split`, `perbaiki`) berpadu dengan kata slide deck, dan menolak konteks medsos.

### 2. Strict Tool Execution Gate pada `runAgentLoop` & `runChatModeLoop`
- Kartu OpenDesign Slide Deck HANYA ditempelkan ke bubble jawaban jika:
  1. Tool `create_slide_deck_design` benar-benar dieksekusi pada giliran tersebut (`touchedSlideTool === true`), ATAU
  2. Pengguna secara eksplisit meminta membuka kembali slide presentasi (`buka slide deck`, `lihat presentasi`).
- Jika prompt bertema feed medsos/gambar (`isSocialFeed`), kartu slide diblokir 100% dan referensi artefak dibersihkan dari bubble asisten.

### 3. Proteksi Router & Master Agent Negative Constraint (Rule 6)
- Menambahkan Rule 6 pada Master Agent System Prompt dan memperbarui deskripsi tool `create_slide_deck_design` dengan larangan keras memanggil tool slide deck untuk feed carousel media sosial.
- Melindungi `isDeckRevisionContext` di `runAgentLoop`, `handleSendMessage`, dan `processNextQueuedPrompt`.

---

## 🧪 Hasil Verifikasi

1. **Unit Test Evaluasi Node.js**:
   - Prompt kasus bug (*"prompt untuk generate image ... trus prompt nya itu per slide feed ..."*):
     - `isSocialMediaOrImagePrompt`: **`true`**
     - `isExplicitSlideDeckIntent`: **`false`**
     - `isSlideDeckRevisionInstruction`: **`false`**
     - Hasil: Diproses sebagai pesan normal, **kartu slide deck TIDAK ditempelkan**.
   - Prompt presentasi (*"buatkan 10 slide deck presentasi profil perusahaan"*):
     - `isExplicitSlideDeckIntent`: **`true`**
     - Hasil: Diproses oleh Master Design / Tool slide deck secara normal.
   - Prompt revisi slide (*"revisi slide 3 dipisah jadi 2 halaman"*):
     - `isSlideDeckRevisionInstruction`: **`true`**
     - Hasil: Diproses sebagai revisi presentasi.

2. **Kepatuhan Sub-800 Baris & Sintaks**:
   - `node -c extension/sidepanel.js` -> Valid (Exit Code 0).
   - Seluruh 12 berkas modular di `extension/design/` dan `extension/apps-integration/` tetap patuh `<= 798` baris.
