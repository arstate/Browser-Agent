# Walkthrough: Perbaikan Bug Inline Code & LaTeX Math Collision (`🪟INLINE_CODE21≡`)

## Ringkasan Perubahan
Bug tampilan di mana pesan obrolan menampilkan placeholder rusak bertuliskan:
`🪟INLINE_CODE21≡ → ≡INLINE_CODE22≡, dan 🪟INLINE_CODE23≡ → ≡INLINE_CODE24≡`
telah berhasil diperbaiki secara tuntas pada ekstensi **Browser Agent** (`v2.150.277`).

![Tangkapan layar bug awal dari pengguna](/home/arya/.gemini/antigravity-cli/brain/24d0de2c-f931-4ce9-b771-b1b1db6dc311/.user_uploaded/uploaded_media_1788855687723.png)

---

## 🔍 Akar Masalah yang Ditemukan
1. **Placeholder Bertanda Underscore (`_`)**:
   Potongan inline code ber-backtick sebelumnya disimpan sebagai token `\uE000INLINE_CODE_${idx}\uE001`.
2. **Tabrakan Regex Subscript LaTeX**:
   Ketika baris pesan memuat simbol panah LaTeX `\rightarrow` atau `$..$`, modul `parseLatexMath()` menjalankan `convertMathTokens()`.
   Regex subscript:
   ```javascript
   s = s.replace(/_{([^}]+)}|_([0-9a-zA-Z\+\-]+)/g, (m, p1, p2) => `<sub>${p1 || p2}</sub>`);
   ```
   keliru mencocokkan karakter `_CODE` dan `_21` pada placeholder itu sendiri, mengubah token menjadi `\uE000INLINE<sub>CODE</sub><sub>21</sub>\uE001`.
3. **Kegagalan Restorasi Kode**:
   Saat `finalHtml.split('\uE000INLINE_CODE_21\uE001')` dieksekusi, pencarian gagal karena token aslinya sudah terpotong tag `<sub>`. Akibatnya, karakter Private Use Area `\uE000` dan `\uE001` bocor ke layar pengguna sebagai glyph kotak tofu (`🪟` dan `≡`) dengan teks subscript `CODE21`.

---

## 🛠️ Modifikasi yang Dilakukan

### 1. Format Placeholder Bebas Benturan (Collision-Free)
Pada [sidepanel.js](file:///home/arya/browser-agent/extension/sidepanel.js), seluruh nama token penampung diubah menjadi alfanumerik murni tanpa karakter underscore:
- `\uE000INLINECODE${idx}\uE001`
- `\uE000CODEBLOCK${idx}\uE001`
- `\uE000TABLEBLOCK${idx}\uE001`
- `\uE000IMAGEBLOCK${idx}\uE001`
- `\uE000FILECARD${idx}\uE001`

### 2. Perlindungan Token di `convertMathTokens()`
Ekspresi matematika dipecah menggunakan regex pembagi `(\uE000[^\uE001]+\uE001)`. Seluruh potongan token placeholder langsung dilewati tanpa modifikasi:
```javascript
const parts = expr.split(/(\uE000[^\uE001]+\uE001)/g);
const resStr = parts.map((part, idx) => {
  if (idx % 2 === 1) return part; // placeholder token, biarkan utuh!
  ...
}).join('');
```

### 3. Isolasi Konteks Subscript & Preservasi Spasi
- Regex subscript `_([0-9a-zA-Z\+\-]+)` dan superscript `\^([0-9a-zA-Z\+\-]+)` kini **hanya aktif** di dalam konteks formula matematika eksplisit (`isExplicitMath: true`), sehingga variabel seperti `user_id` atau `session_id` pada teks polos tidak dirusak menjadi subscript.
- Menghapus `s.trim()` parsial pada potongan non-matematika agar spasi antar-token inline code dan simbol panah tetap rapi dan presisi.

### 4. Fail-Safe PUA Control Character Sweep
Menambahkan pembersih pengaman di penutup fungsi `formatMarkdown()`:
```javascript
finalHtml = finalHtml.replace(/\uE000(?:INLINECODE|CODEBLOCK|TABLEBLOCK|IMAGEBLOCK|FILECARD)\d+\uE001/g, '');
finalHtml = finalHtml.replace(/[\uE000\uE001]/g, '');
```

### 5. Bump Versi & Dokumentasi
- [manifest.json](file:///home/arya/browser-agent/extension/manifest.json): Versi dinaikkan ke `v2.150.277`.
- [dokumentasi.md](file:///home/arya/browser-agent/dokumentasi.md), [design.md](file:///home/arya/browser-agent/design.md), dan [agent_histori_chat.md](file:///home/arya/browser-agent/agent_histori_chat.md) diperbarui mencatat Iterasi 160 / Desain 53.

---

## 🧪 Hasil Pengujian & Validasi

| Skenario Uji | Teks Masukan | Hasil Tampilan | Status |
| :--- | :--- | :--- | :---: |
| **Kasus Nyata Pengguna** | `*Halaman 9:* Ubah \`Puri (2025)\` $\rightarrow$ \`(2024)\`, dan \`Abdurrahman (2025)\` $\rightarrow$ \`Irfan (2022)\`.` | 4 badge inline code abu-abu rapi diapit panah `→` tanpa kebocoran placeholder | **PASSED** |
| **Variabel Snake Case** | `Nilai user_id dan session_id valid.` | Teks tetap `user_id` dan `session_id` (tidak berubah jadi subscript) | **PASSED** |
| **Formula Matematika** | `$x_1 + x_2 = y_{max}$` | Ter-render sebagai rumus matematika dengan subscript `x₁ + x₂ = y_max` | **PASSED** |
| **Tabel Markdown** | Baris tabel berisi \`code\` dan simbol LaTeX $\rightarrow$ | Sel tabel memuat pill kode dan simbol tanpa merusak struktur HTML tabel | **PASSED** |
| **Syntax Validation** | `node -c extension/sidepanel.js` | Bebas dari syntax error | **PASSED** |
| **Sub-800 Line Rule** | Seluruh file di `design/` & `apps-integration/` | 100% patuh di bawah 800 baris | **PASSED** |
