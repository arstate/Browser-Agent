# 🚀 Walkthrough: Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing (v2.150.288)

## 📌 Ringkasan Masalah & Sasaran
Sebelumnya, ketika pengguna meminta evaluasi dokumen magang/proposal (misalnya *"coba cek proposal magang saya"* atau melampirkan berkas `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf`), sistem auto-agent secara keliru memilih agen komersial **Tiar Property - Meta Ads Auditor**.

### 🔍 Akar Masalah Teknis
1. **Kebocoran Kata Kerja Generik**: Kata kerja umum seperti `cek`, `lihat`, `periksa`, `analisis` sebelumnya tercakup di dalam `isAuditQuery`, yang secara otomatis mengaktifkan `isAdsQuery = (isAdsQuery || isAuditQuery)`. Akibatnya, setiap kalimat dengan kata "cek" langsung dicap sebagai query Meta Ads.
2. **Bias Kata Nama Agent Auditor**: Agen `Tiar Property - Meta Ads Auditor` memiliki kata kunci `auditor` di namanya sehingga langsung dihadiahi skor +35 saat kata `cek` muncul.
3. **Kebutaan Terhadap Lampiran Berkas**: Fungsi seleksi agen `resolveAutoAgents(userMessage, explicitMentions)` sebelumnya tidak menerima parameter lampiran `attachments`.
4. **Pencemaran Lintas Domain**: Tidak ada diskualifikasi domain yang memisahkan ekosistem komersial perumahan Tiar Property dengan kebutuhan akademik/magang Kominfo.

---

## 🛠️ Solusi Rekayasa yang Diimplementasikan

### 1. Attachment-Aware Semantic Recruitment Pipeline (`extension/sidepanel.js`)
Fungsi `resolveAutoAgents` kini menerima berkas lampiran `attachments`:
```javascript
function resolveAutoAgents(userMessage = "", explicitMentionAgents = [], attachments = []) {
  // Ekstraksi nama berkas lampiran
  const attachmentNames = Array.isArray(attachments) ? attachments.map(a => a.name || a.filename || "").filter(Boolean) : [];
  const attachmentStr = attachmentNames.join(" ").toLowerCase();
  const combinedContext = (userMessage + " " + attachmentStr).toLowerCase();
  // ...
}
```

### 2. Domain Silo Isolation & Decoupling Kata Kerja Netral
- Kata kerja `cek`, `lihat`, `periksa`, `analisis` didecouple sepenuhnya dari detektor iklan. Domain Meta Ads kini hanya aktif untuk kata domain spesifik (`meta ads`, `iklan`, `cpr`, `boncos`, dll.).
- Saat domain akademik/magang terdeteksi (`isInternshipDomain`), seluruh agen real estate komersial (`Tiar Property`) **langsung didiskualifikasi (skor = 0)**:
```javascript
if (isInternshipDomain) {
  if (idLower.includes("arya") || nameLower.includes("arya") || idLower.includes("magang") || nameLower.includes("magang")) {
    score += 150;
  }
  // STRICT DOMAIN SILO ISOLATION:
  if (agentBrand === "tiar_property") {
    score = 0; // Diskualifikasi mutlak agen komersial real estate
  }
}
```

### 3. Pemetaan Brand & Sasaran Milestone (`extension/core/goal_tracker.js`)
- `detectBrand` memetakan istilah `proposal`, `magang`, `internship`, `kominfo`, `logbook`, `laporan akhir`, `arya` ke `bangga_surabaya`.
- `inferAgentForTask` menugaskan milestone peninjauan dokumen akademik ke `ARYA-MAGANG-KOMINFO`.

---

## 🧪 Hasil Pengujian Otomatis

Unit test otomatis dijalankan via simulasi Node.js dengan 5 skenario nyata:
```
[TEST 1] Query: "coba cek proposal magang saya"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 2] Query: "tolong periksa halaman 3" + Attachment: "PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf"
  Selected: ARYA-MAGANG-KOMINFO (Brand: bangga_surabaya) -> PASSED!

[TEST 3] Query: "cek iklan fb yang boncos"
  Selected: Tiar Property - Meta Ads Auditor -> PASSED!

[TEST 4] Query: "berapa angsuran kpr rumah di sukodono dp 0%"
  Selected: Tiar Property - Sales Closer CS -> PASSED!

[TEST 5] Query: "bikin script python terminal linux"
  Selected: Coding & System Engineer -> PASSED!

==================================================
🎉 ALL 5 AUTO-AGENT ROUTING TESTS PASSED 100%!
==================================================
```

---

## 📦 Verifikasi Versi & Restore Point
- **Versi Rilis**: `v2.150.288`
- **Pembaruan Berkas**:
  - `extension/manifest.json`: Versi dinaikkan ke `2.150.288`.
  - `extension/sidepanel.js`: Implementasi Dynamic Semantic Agent Roster Selection & Attachment-Aware Routing.
  - `extension/core/goal_tracker.js`: Pemetaan brand & agen milestone untuk ARYA-MAGANG-KOMINFO.
  - `dokumentasi.md`: Catatan 171 ditambahkan.
  - `design.md`: Bagian 64 ditambahkan.
  - `agent_histori_chat.md`: Iterasi 171 ditambahkan.
- **Kepatuhan Sub-800 Baris**: Seluruh 12 berkas di `extension/design/` dan `extension/apps-integration/` tetap patuh `<= 798` baris.

---

# ⚡ Walkthrough: True KV Cache & Prefix Pinning Optimizer Engine (v2.150.289)

## 📌 Masalah & Akar Penyebab
- **0% Cache Hit di Headroom Proxy & 9Router**: Dari 1.57 juta token yang diproses oleh proxy Headroom (port 8787), terjadi 0% cache read akibat `miss_attribution: prefix_change` pada setiap permintaan.
- **Root Cause**: `buildDynamicSystemPrompt` menyuntikkan timestamp lokal dinamis di baris pertama prompt (`getDetailedCurrentTimeContext()`), memutasi byte-byte awal setiap detik/menit.
- **Placebo String**: Teks plugin `• [PLUGIN: KV CACHE OPTIMIZER...]` membuang ~60 token tanpa fungsi teknis caching.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Prefix Pinning 100% Statis**: System Prompt dan array skema tools dijaga 100% beku tanpa variabel dinamis.
2. **Dynamic Suffix Relocation**: Seluruh variabel waktu lokal dan URL tab aktif dipindahkan ke **Suffix pesan user terakhir** (`=== 🕒 DYNAMIC EXECUTION CONTEXT (SUFFIX - ISOLATED FOR KV CACHE) ===`).
3. **Penyortiran Tools Deterministik**: Array tools disortir secara alfabetis berdasarkan `function.name`.
4. **Provider Cache Control Injection**: Menyuntikkan `cache_control: { type: "ephemeral" }` untuk Anthropic Claude, DeepSeek, dan Headroom Proxy.
5. **Multi-Turn Synchronization**: Pesan user yang telah disisipkan suffix disinkronkan ke `conversationHistory` / `conversationTurns`, menjamin turn lampau tetap 100% bit-exact di turn berikutnya.
6. **Eliminasi Placebo Bloat**: Menghapus teks placebo ~60 token dari `sidepanel.js` dan `background.js`.

---

# 🏛️ Walkthrough: Claude Fable & Claude Opus 5 3-Line Cognitive Distillation (v2.150.290)

## 📌 Masalah & Akar Penyebab
- **Token Inflation ~500 Token**: Plugin Claude Fable dan Claude Opus 5 sebelumnya menyuntikkan esai 500 token tentang struktur folder markdown Obsidian (`/profile.md`, `/topics/`, `/areas/`) yang tidak pernah dipakai.
- **XML Tag Placebo**: Tag `<antml:reasoning_effort>` diabaikan oleh backend Google/OpenAI di 9Router.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Distilasi 3-Baris Ringkas (~30 Token)**:
   - Direktif dikompresi menjadi 3 baris presisi tinggi:
     1. *Accountability Without Self-Abasement*: Langsung ke solusi teknis lugas. DILARANG minta maaf berlebihan atau bersikap submissive saat dikritik.
     2. *Direct Prose & Zero Fluff*: Langsung ke poin inti tanpa kalimat pembuka/penutup klise. DILARANG menarasikan memori ("Berdasarkan ingatan...").
     3. *Truth-Seeking & Anti-Sycophancy*: Utamakan kebenaran faktual di atas kepatuhan buta (anti-flattery). Berani berikan sanggahan konstruktif.
   - Menghemat ~470 token di setiap pesan.
2. **Penanaman ke Default Core System Prompt**:
   - Ditanamkan langsung ke `DEFAULT_SYSTEM_PROMPT` (Agent Mode), `CHAT_ONLY_SYSTEM_PROMPT` (Chat Mode), dan `systemInstruction` (Telegram Bot). Karakter tegas dan lugas aktif permanen.

---

# 🔘 Walkthrough: Pure Toggle Switches UI & Redundant Modal Elimination (v2.150.291)

## 📌 Masalah & Akar Penyebab
- **Pengaturan Placebo / Redundan**: Tombol "Settings" dan modal dialog pada 3 plugin (KV Cache Optimizer, Claude Fable 5, dan Claude Opus 5 Distill) berisi slider Reasoning Effort, selector Tier, dan checkbox taksonomi file Obsidian yang tidak lagi berguna pasca pemadatan direktif kognitif 3 baris (~30 token) dan penanganan prefix KV Cache otomatis.
- **Beban DOM Berlebih**: 3 modal overlay membebani `extension/options.html` dengan total ~387 baris HTML tak terpakai.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Penghapusan Tombol Settings pada Kartu Plugin (`extension/options.html`)**:
   - Menghapus tombol `btn-config-kvcache`, `btn-config-claude-fable`, dan `btn-config-claude-opus-5`.
   - Mengubah tampilan kartu menjadi minimalis murni dengan toggle switch On/Off dan status aktif/nonaktif yang jelas.
2. **Pembersihan 3 Modal Dialog Konfigurasi (`extension/options.html`)**:
   - Menghapus `#modal-plugin-kvcache`, `#modal-claude-fable-config`, dan `#modal-claude-opus-5-config`.
   - Mengurangi 387 baris kode HTML tak terpakai.
3. **Preservasi Fungsionalitas Storage & Null-Safety Guard**:
   - State On/Off tetap disimpan ke `chrome.storage.local` (`plugin_settings.kvcache.enabled`, `claude_fable.enabled`, `claude_opus_5.enabled`).
   - Seluruh script pengendali plugin tetap berjalan normal tanpa error berkat guard null-checking.
4. **Verifikasi & Standar Sub-800 Baris**:
   - Validasi sintaksis `node -c` lulus 100%.
   - Seluruh 12 berkas di `extension/design/` dan `extension/apps-integration/` tetap patuh ketat `<= 798` baris.

---

# 🎨 Walkthrough: Master Design Brief Precision, Fixed 16:9 Virtual Canvas Autoscale, Cross-Platform Windows PDF Export, & Temporary Chat (v2.150.292)

## 📌 Masalah & Akar Penyebab
1. **Brief Desain Hilang / Terpotong**: Pada mode Design Mode, `cleanPresentationTopic` memotong input string prompt menjadi hanya 45 karakter dan hanya menyisipkan judul topik generic tanpa instruksi bab/detail pengguna, menyebabkan AI berhalusinasi dan menghasilkan materi ngawur. Sementara pada Open Canvas revisi, prompt revisi diteruskan penuh sehingga AI paham.
2. **Slide Deck Responsive & Teks Pecah Saat Zoom**: Preview slide menggunakan CSS lebar relatif (`width: min(1200px, 100%, ...)`), sementara font dan margin statis. Saat browser di-zoom atau drawer menyempit, wadah mengecil tapi font tetap besar sehingga terjadi wrapping teks canggung dan overflow kartu keluar rasio 16:9.
3. **Error Ekspor PDF di Windows**: Native host Python `export_slide_deck_pdf` menulis file sementara ke hardcoded Unix path `/tmp/deck_{ts}.html` yang tidak ada di OS Windows (`FileNotFoundError: No such file or directory`), serta kurangnya path executable Chrome/Edge Windows.
4. **Fitur Temporary Chat**: Diperlukan tombol obrolan sementara (*icon only*) di navbar atas New Tab agar percakapan bersifat ephemeral tanpa tercatat ke IndexedDB riwayat obrolan.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Injeksi Brief Lengkap ke Prompt Master Design (`design_agent.js` & `design_executor.js`)**:
   - Menambahkan parameter `userBrief` ke `createSlidePromptForMasterDesign()` dan menyisipkan blok `BRIEF & INSTRUKSI LENGKAP PENGGUNA` ke prompt AI.
   - Menambahkan parser `extractCustomUserOutline()` pada `createDefaultBlueprint()` untuk membaca struktur bab kustom yang diberikan pengguna.
   - Meneruskan `userMessage` ke pemanggilan `fetchSlideContentFromAI()` untuk Slide 1 (Cover) dan slide konten lanjutan.
2. **Fixed Virtual 16:9 Canvas (1200x675 px) & Proportional CSS Transform Autoscale (`slide_styles.js` & `slide_deck_engine.js`)**:
   - Mengunci `.slide-section` pada ukuran tetap `width: 1200px !important; height: 675px !important; position: absolute; transform-origin: center center;`.
   - Mengimplementasikan `initSlideDeckAutoscale()` yang mengukur lebar/tinggi pembungkus panggung (`.deck-stage-wrap`) dan menyetel `transform: scale(Math.min(availW / 1200, availH / 675))` secara dinamis via `window.resize` dan `ResizeObserver`.
3. **Universal Cross-Platform PDF Rendering Host (`host/native_host.py`)**:
   - Menggunakan `tempfile.gettempdir()` dan `os.path.join()` untuk menyimpan file HTML sementara dan hasil render PDF.
   - Mendeteksi binary browser Google Chrome dan Microsoft Edge di Windows (`%ProgramFiles%\Google\Chrome`, `%LocalAppData%\Google\Chrome`, `%ProgramFiles(x86)%\Microsoft\Edge`, `chrome.exe`, `msedge.exe`).
4. **Fitur Temporary Chat Icon-Only (`newtab.html`, `newtab.css`, `sidepanel.css`, `sidepanel.js`)**:
   - Menambahkan tombol `#btn-temporary-chat` (ikon fedora hat + glasses) di navbar kanan New Tab di samping `#chip-system-tab`.
   - Menambahkan efek active glow amber pada `.btn-temporary-chat.active`.
   - Menerapkan bypass penyimpanan `if (isTemporaryChatActive) return;` di `saveCurrentSessionToDB()` dan `executeSaveCurrentSessionToDB()`.
5. **Verifikasi & Standar Sub-800 Baris**:
   - Validasi sintaksis `node -c extension/design/*.js extension/sidepanel.js` dan `python3 -m py_compile host/native_host.py` lulus 100%.
   - Seluruh 12 berkas modular di `extension/design/` dan `extension/apps-integration/` tetap patuh ketat `<= 798` baris.

---

# 🕶️ Walkthrough: Instant Ephemeral New Chat & Eliminasi Halusinasi Typo Vision Dokumen (v2.150.293)

## 📌 Masalah & Akar Penyebab
1. **Perilaku Tombol Temporary Chat**: Pengguna menginginkan ketika tombol Temporary Chat diklik, sistem langsung memulai New Chat yang bersih dan obrolan tersebut tidak disimpan ke riwayat obrolan (*ephemeral*). Sebelumnya, tombol hanya mengubah flag boolean tanpa langsung mereset layar antarmuka chat.
2. **Halusinasi Typo Vision Dokumen PDF/DOCX**: Pada dokumen proposal yang diunggah pengguna (`PROPOSAL INDIVIDU ARYA MAGANG KOMINFO`), AI melaporkan typo false positive tanda kurung buka ganda `((@surabaya palet merah #D71920).` padahal dokumen aslinya tunggal `(@surabaya...`.
   - *Akar Masalah 1*: Ilusi optik font Times New Roman (Serif) di mana karakter `@` memiliki spiral kurva luar berbentuk `C` yang menempel pada `(`, membentuk tampilan optik menyerupai `((@`.
   - *Akar Masalah 2*: Kompresi JPEG 80 pada 140 DPI memicu ringing artifact pada celah 1 piksel tersebut.
   - *Akar Masalah 3*: Vision model memprioritaskan citra raster di atas teks digital karena ketiadaan mandat hierarki strict.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Instant Ephemeral New Chat pada Temporary Chat Toggle (`extension/sidepanel.js` & `extension/sidepanel.html`)**:
   - Mengaktifkan Mode Sementara: Menyimpan chat normal yang sedang aktif ke database, mengaktifkan `isTemporaryChatActive = true`, memanggil `startNewChat()` untuk membersihkan tampilan pesan dan mereset state, mengaktifkan status tombol `.btn-temporary-chat.active`, menampilkan label `🕶️ Temporary Chat` pada header, dan memunculkan toast info.
   - Mematikan Mode Sementara: Memanggil `startNewChat()` sebelum mematikan flag sehingga percakapan sementara langsung dibuang tanpa disimpan ke database, lalu membuka chat normal baru.
   - Guard `ensureCurrentSessionInitialized` & `loadSessionFromStorage`: Tidak menulis session ID ke `sessionStorage` saat temporary chat aktif, dan otomatis menonaktifkan temporary chat jika pengguna membuka sesi tersimpan dari daftar riwayat.
   - Penambahan tombol `#btn-temporary-chat` di header `sidepanel.html` agar konsisten dengan `newtab.html`.
2. **Dual-Layer Ground Truth Hierarchy pada Core System Prompts (`sidepanel.js` & `background.js`)**:
   - Menetapkan direktif bahwa `[Teks Digital Asli (Stream Ground Truth Ejaan & Karakter)]` adalah otoritas 100% mutlak untuk ejaan, kata ganda, karakter, tanda baca, kurung, dan angka.
   - Melarang halusinasi ilusi optik ligatur font Serif `(@` menjadi `((@`.
   - Menugaskan Teks Digital untuk konten teks/ejaan, dan Citra Visual khusus untuk layout, kerapian tabel, margin, dan tanda tangan basah/cap.
3. **Peningkatan Resolusi Render Dokumen (150 DPI & Quality 88) (`host/doc_parser.py`, `host/native_host.py`, `host/rust_host/src/main.rs`)**:
   - Menaikkan DPI default rendering dari 140 ke 150 DPI.
   - Menaikkan parameter JPEG quality dari 80 ke 88 (`-jpegopt quality=88,progressive=y`), menghilangkan artefak ringing DCT 8x8 pada celah antar-karakter.

## 🧪 Hasil Verifikasi & Pengujian
1. **Sintaksis JavaScript & Python**:
   - `node -c extension/sidepanel.js extension/background.js` -> PASSED (0 errors).
   - `python3 -m py_compile host/doc_parser.py host/native_host.py` -> PASSED (0 errors).
   - `cargo check` di `host/rust_host` -> PASSED (0 errors).
2. **Kepatuhan Batas Sub-800 Baris**:
   - Seluruh 12 berkas modular di `extension/design/` dan `extension/apps-integration/` tetap patuh ketat `<= 798` baris.
3. **Bump Versi**:
   - `extension/manifest.json` dinaikkan ke versi `2.150.293`.

---

# 🛠️ Walkthrough: Eliminasi Syntax Error KETAT & scale pada OpenDesign, Infinite Recursion Guard, & Bulletproof Fallback workingSlides (v2.150.294)

## 📌 Masalah & Akar Penyebab
1. **Uncaught SyntaxError: Unexpected identifier 'KETAT'**:
   - Pada `design_agent.js:547`, ekspresi `${coverDirective}\`` ditutup secara prematur oleh karakter backtick liar. Baris selanjutnya (`ATURAN KETAT:`) diurai sebagai token JavaScript biasa di luar string sehingga browser menolak memuat `design_agent.js`.
2. **Uncaught SyntaxError: Unexpected identifier 'scale'**:
   - Pada `slide_deck_engine.js:569`, kode autoscale di dalam template string runtime script menggunakan nested template literal tanpa escape: `slides[i].style.transform = \`scale(${scale})\`;`. Backtick dalam menutup template string pembungkus luar dan memicu syntax error, menyebabkan browser menolak memuat `slide_deck_engine.js`.
3. **Cannot read properties of undefined (reading 'title')**:
   - Akibat `design_agent.js` gagal dimuat, generator blueprint `createDefaultBlueprint` tidak tersedia. Fallback menghasilkan `{ slides: [] }` sehingga `workingSlides[0]` bernilai undefined saat diakses propertinya di `design_executor.js`.
4. **Uncaught RangeError: Maximum call stack size exceeded**:
   - Akibat `slide_deck_engine.js` gagal dimuat, pemanggilan `upgradeSlideDeckHtmlIfNeeded` saat membuka canvas jatuh ke fallback shim di `sidepanel.js` yang memanggil `window.upgradeSlideDeckHtmlIfNeeded` (merujuk ke dirinya sendiri), menyebabkan infinite recursion loop dan menggagalkan pembukaan canvas.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Perbaikan Template Literal `design_agent.js`**:
   - Menghapus backtick penutup liar di `${coverDirective}` pada `extension/design/design_agent.js:547`.
2. **Perbaikan Nested Template Literal `slide_deck_engine.js`**:
   - Mengganti nested template literal menjadi string concatenation `'scale(' + scale + ')'` pada `extension/design/slide_deck_engine.js:569`.
3. **Guard Infinite Recursion di `sidepanel.js`**:
   - Mengubah fallback shim `upgradeSlideDeckHtmlIfNeeded` untuk memeriksa `window.upgradeSlideDeckHtmlIfNeeded !== upgradeSlideDeckHtmlIfNeeded`.
4. **Bulletproof Fallback workingSlides di `design_executor.js`**:
   - Menginisialisasi `workingSlides` dengan slide cover default jika `defaultBp.slides` kosong.
   - Menambahkan optional chaining pada `(workingSlides[sIdx - 1]?.title || '')`.

## 🧪 Hasil Verifikasi & Pengujian
1. **Sintaksis Check Seluruh JS**:
   - `for f in extension/*.js extension/design/*.js extension/apps-integration/*.js extension/core/*.js; do node -c "$f"; done` -> **PASSED (0 errors)**.
2. **Kepatuhan Sub-800 Baris**:
   - Seluruh 12 berkas modular tetap patuh ketat `<= 798` baris (`design_executor.js`: 795, `slide_editor.js`: 798).
3. **Bump Versi**:
   - `extension/manifest.json` dinaikkan ke versi `2.150.294`.

---

# 🚪 Walkthrough: Auto-Close Slide Deck Canvas Drawer saat Navigasi ke Home / Mulai Chat Baru (v2.150.295)

## 📌 Masalah & Akar Penyebab
1. **Drawer Canvas Tetap Terbuka saat Klik Home**:
   - Saat pengguna berada di mode Open Canvas (misal melihat preview slide deck presentasi) dan mengklik tombol Home (`#btn-header-new-chat` di sidebar), tampilan berpindah ke status Home namun drawer kanvas di sisi kanan `#opendesign-canvas-pane` tidak tertutup otomatis dan tetap menggantung di layar.
2. **Omission of Canvas Teardown**:
   - Event listener `#btn-header-new-chat` di `extension/newtab.js` hanya memanggil `closeFullscreenSettings()` dan `closeAppsView()`, sama sekali tidak memanggil `closeOpenDesignCanvas()`.
3. **Missing Cleanup in Lifecycle Reset Functions**:
   - Fungsi `startNewChat()` dan `resetChatMessagesUI()` di `extension/sidepanel.js` tidak memanggil `closeOpenDesignCanvas()`, membiarkan kelas `.canvas-active` tetap menempel di `document.body` dan drawer kanvas tetap berstatus `display: flex`.
4. **CSS Priority Masking Hero Welcome**:
   - Di `extension/newtab.css`, aturan `body.canvas-active .welcome-card` memiliki properti `display: none !important;`. Selama `.canvas-active` belum dicabut dari `body`, kartu hero Home tidak dapat muncul, dan kolom chat terkunci pada lebar sempit `440px`.

## 🛠️ Solusi Rekayasa yang Diimplementasikan
1. **Integrasi Canvas Auto-Close di Navigasi Home (`extension/newtab.js`)**:
   - Memperbarui event listener tombol Home `#btn-header-new-chat` dan logo brand `#btn-sidebar-brand` dengan memanggil `closeOpenDesignCanvas()`.
   - Menghapus kelas `has-messages`, mengembalikan `.welcome-card` ke `display: flex`, dan mereset scroll halaman ke puncak (`scrollTop = 0`).
2. **Pembersihan Siklus Hidup Obrolan (`extension/sidepanel.js`)**:
   - Menyuntikkan pemanggilan `closeOpenDesignCanvas()` di awal `startNewChat()`, `resetChatMessagesUI()`, dan `resumeSession()`.
   - Mengosongkan memori artefak aktif `activeDesignArtifact = null`, `window.__activeDesignArtifact = null`, dan menghapus `sessionStorage.removeItem('canvas_was_open')`.
3. **Event Delegation Safeguard di Canvas Manager (`extension/design/canvas_manager.js`)**:
   - Menambahkan id tombol Home dan New Chat ke daftar listener penutupan canvas:
     `['btn-canvas-close', 'btn-header-new-chat', 'btn-history-new-chat', 'btn-sidebar-brand'].forEach(...)`.
   - Menjaga jumlah baris `canvas_manager.js` tetap tepat 794 baris (di bawah limit 798 baris).

## 🧪 Hasil Verifikasi & Pengujian
1. **Sintaksis Check JavaScript**:
   - `node -c extension/design/canvas_manager.js extension/newtab.js extension/sidepanel.js` -> **PASSED (0 errors)**.
2. **Kepatuhan Batas Sub-800 Baris**:
   - `extension/design/canvas_manager.js`: 794 baris (aman `<= 798`).
   - Seluruh 12 berkas modular patuh ketat `<= 798` baris.
3. **Bump Versi**:
   - `extension/manifest.json` dinaikkan ke versi `2.150.295`.




