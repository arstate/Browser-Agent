# 🎯 ANALISIS & RENCANA PERBAIKAN: PRESISI PEMILIHAN AUTO-AGENT (ANTI-SALAH REKRUT)

Dokumen ini membedah secara tuntas penyebab mengapa **Auto-Agent Selector** salah memilih agent (misal: konteks proposal magang malah merekrut *Tiar Property Meta Ads Auditor*), serta merancang solusi permanen berbasis **Domain Intent Disambiguation** dan **Attachment-Aware Agent Routing**.

---

## 🔍 1. ANATOMI MASALAH: MENGAPA TIAR PROPERTY YANG TERPILIH?

Setelah membedah kode `resolveAutoAgents` di `extension/sidepanel.js` (baris 713–870), kami menemukan **4 anomali sistemik**:

### Anomali 1: Kata Kerja Umum ("Cek", "Lihat", "Analisis") Terikat ke Iklan Meta Ads
Di dalam `extension/sidepanel.js` baris 715–740:
```javascript
const isAuditQuery = (
  text.includes("cek") || text.includes("audit") || text.includes("lihat") ||
  text.includes("pantau") || text.includes("evaluasi") || text.includes("periksa") ||
  text.includes("analisis") || text.includes("analisa") || text.includes("detail")
);

const isAdsQuery = (
  text.includes("ads") || text.includes("iklan") || text.includes("lead") ||
  isAuditQuery || isStrategyQuery // <--- BIANG KEROK UTAMA!
);
```
- **Masalah:** Kata `"cek"`, `"lihat"`, `"periksa"`, dan `"analisis"` adalah kata kerja sehari-hari bahasa Indonesia.
- Karena `isAuditQuery` dimasukkan ke dalam `isAdsQuery`, setiap kali pengguna mengetik:
  - *"Coba **cek** proposal magang saya"*
  - *"Tolong **lihat** bab 2"*
  - *"Tolong **analisis** dokumen ini"*
  Sistem secara keliru menganggap pertanyaan tersebut adalah **Topik Iklan Meta Ads (`isAdsQuery = true`)**!

### Anomali 2: Agent `tiar_meta_ads_auditor` Mendapat Skor Otomatis +35
Di baris 852–865:
```javascript
if (isAdsQuery) {
  const isAuditorRole = (nameLower.includes("auditor") || idLower.includes("auditor"));
  if (isAuditQuery && isAuditorRole) {
    score += 35; // <--- Memberikan +35 poin ke Tiar Meta Ads Auditor!
  }
}
```
Karena `isAuditQuery = true` dan `isAdsQuery = true`, agent **Tiar Property - Meta Ads Auditor** langsung mendapatkan skor tinggi (+35), padahal pengguna sama sekali tidak sedang membahas perumahan atau iklan Facebook!

### Anomali 3: Tidak Ada Kategori Intent untuk "Proposal", "Magang", & "Dokumen Akademik"
Di sistem saat ini, kategori scoring hanya mencakup:
- Casual/Companion, Meta Ads, Copywriting, Property Sales/KPR, CRM Admin, Visual Design, Coding, Research, Browser Control, dan Academic Thesis (`unesa`, `skripsi`, `thesis`, `jurnal`, `sidang`).
- **Kata `"proposal"`, `"magang"`, `"internship"`, `"sib"`, `"logbook"`, `"laporan"`, `"sipintar"` TIDAK TERDAFTAR di kategori manapun!**
- Akibatnya, agent spesialis Anda yaitu **`ARYA-MAGANG-KOMINFO` (`arya_magang_kominfo`)** mendapatkan **skor 0 (NOL)**, sehingga kalah telak melawan Tiar Property yang mendapat skor 35!

### Anomali 4: Auto-Agent Buta Terhadap Lampiran Dokumen (Attachment Blindness)
Fungsi `resolveAutoAgents` saat ini hanya membaca teks prompt (`userMessage`). Padahal saat Anda mengunggah dokumen:
- Nama berkasnya jelas-jelas: `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf`.
- Karena sistem tidak membaca nama berkas lampiran, sistem tidak tahu bahwa konteks kerja saat itu 100% adalah dokumen proposal magang Kominfo Arya.

---

## 🛠️ 2. ARSITEKTUR SOLUSI: 4 PILAR PRESISI REKRUTMEN AGENT

```mermaid
graph TD
    A[Input Pengguna & Dokumen Lampiran] --> B[Attachment & Context Inspection]
    B --> C{Apakah Nama Berkas / Prompt Mengandung Magang / Proposal / Kominfo?}
    C -- YA --> D[🎯 Kunci Ekosistem: 'bangga_surabaya' / 'academic_internship']
    D --> E[Beri Skor Tertinggi +60 ke ARYA-MAGANG-KOMINFO]
    D --> F[⛔ DISKUALIFIKASI MUTLAK Seluruh Agent Tiar Property & Real Estate]
    
    C -- BUKAN --> G[Domain Intent Matching Murni]
    G --> H[Lepaskan 'cek/lihat/analisis' dari isAdsQuery]
    H --> I{Hanya picu Ads jika ada kata 'iklan/ads/cpr/lead'}
```

### Pilar 1: Pemisahan Tegas Kata Kerja Umum dari Meta Ads
- Kata `"cek"`, `"lihat"`, `"periksa"`, `"analisis"`, `"status"`, `"detail"` dikembalikan fungsinya sebagai kata kerja umum.
- `isAdsQuery` **HANYA** bernilai `true` jika prompt memang memuat istilah periklanan nyata (`ads`, `iklan`, `campaign`, `kampanye`, `meta ads`, `fb ads`, `cpr`, `cpl`, `roas`, `adset`, `lead`).
- Kata kerja umum tanpa konteks iklan tidak akan pernah lagi memberikan poin ke agent iklan Tiar Property!

### Pilar 2: Domain Intent Baru: `isProposalOrInternshipQuery`
Menambahkan deteksi intent dokumen magang & akademik vokasi:
```javascript
const isProposalOrInternshipQuery = (
  text.includes("proposal") || text.includes("magang") || text.includes("internship") ||
  text.includes("diskominfo") || text.includes("kominfo") || text.includes("sipintar") ||
  text.includes("logbook") || text.includes("laporan akhir") || text.includes("portofolio") ||
  text.includes("studi independen") || text.includes("sib") || text.includes("humanizer") ||
  text.includes("surabaya") || text.includes("sapawarga") || text.includes("d4 desain")
);
```
Jika terdeteksi:
- Agent `arya_magang_kominfo` otomatis mendapat boost **+60 poin**.
- Seluruh agent brand lain (Tiar Property, DGA, Djadi) otomatis **didiskualifikasi 100% (Skor 0)**.

### Pilar 3: Attachment-Aware Agent Resolution (Membaca Nama File)
Memperbarui pemanggilan fungsi:
`resolveAutoAgents(userMessage, explicitMentions, attachments)`
- Sistem memeriksa seluruh berkas lampiran di `attachments` (`name`, `path`, `file_name`).
- Jika nama berkas memuat kata `proposal`, `magang`, `kominfo`, `sipintar`, `logbook`, atau `unesa`:
  Sistem langsung menetapkan konteks kerja ke **`ARYA-MAGANG-KOMINFO`**, bahkan jika pengguna hanya mengetik prompt singkat seperti *"Tolong cek halaman 3 bro"*.

### Pilar 4: Strict Anti-Cross Brand Disqualification Guard
Jika prompt atau lampiran mengindikasikan urusan magang/kampus/Kominfo, sistem menerapkan aturan tegas:
```javascript
if (isProposalOrInternshipQuery && (agentBrand === 'tiar_property' || idLower.includes('tiar'))) {
  continue; // DISKUALIFIKASI TOTAL: 0% kemungkinan Tiar Property terpilih!
}
```

---

## 📋 3. RENCANA PERUBAHAN BERKAS

| No | Berkas | Perubahan yang Diusulkan |
|---|---|---|
| 1 | `extension/sidepanel.js` | 1. Perbaiki `resolveAutoAgents` agar menerima argumen `attachments`.<br>2. Pisahkan `isAuditQuery` dari `isAdsQuery`.<br>3. Tambahkan `isProposalOrInternshipQuery` dengan bobot +60 untuk `arya_magang_kominfo`.<br>4. Tambahkan diskualifikasi mutlak bagi agent properti saat membahas proposal/magang. |
| 2 | `extension/core/goal_tracker.js` | Sinkronkan `detectBrand` dan `inferAgentForTask` agar saat mendeteksi kata proposal/magang langsung mengunci penanggung jawab ke `ARYA-MAGANG-KOMINFO`. |

---

## 🧪 4. RENCANA PENGUJIAN & VERIFIKASI

1. **Uji Kasus 1:** Prompt *"Coba cek proposal magang saya"* -> Harus merekrut **ARYA-MAGANG-KOMINFO**, Tiar Property 0 poin.
2. **Uji Kasus 2:** Upload PDF proposal magang + prompt *"Tolong cek isi bab 2"* -> Harus otomatis merekrut **ARYA-MAGANG-KOMINFO** berkat deteksi nama file.
3. **Uji Kasus 3:** Prompt *"Cek iklan rumah di Surabaya yang boncos"* -> Harus merekrut **Tiar Property Meta Ads Auditor**.
