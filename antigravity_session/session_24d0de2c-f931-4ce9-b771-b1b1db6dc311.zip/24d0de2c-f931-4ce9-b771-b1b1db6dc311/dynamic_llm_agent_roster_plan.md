# 🎯 ARSITEKTUR: DYNAMIC LLM AGENT ROSTER & SEMANTIC SELECTION (ANTI-KEYWORD REGEX)

Dokumen ini menjawab pertanyaan Anda: **apakah metode membiarkan AI menyimpulkan sendiri kebutuhan agennya berdasarkan daftar katalog agen (Agent Roster) dijamin lebih akurat?** Serta merancang arsitektur implementasinya secara tuntas.

---

## 💡 1. JAWABAN LANGSUNG: APAKAH DIJAMIN AKURAT?

> **JAWABAN: YA, 1000% JAUH LEBIH AKURAT!**
> Ini adalah lompatan besar dari era *Hardcoded Regex Keyword Matching* ke era **Autonomous Agentic Orchestration** (seperti yang digunakan AutoGen, CrewAI, dan Google Antigravity).

### Mengapa Cara Lama (Query Kata Kunci Manual) Sering Gagal?
| Aspek | Cara Lama (Regex Keyword) | Cara Baru (LLM Agent Roster) |
|---|---|---|
| **Logika** | Kaku: `text.includes("cek")` | Cerdas: Memahami konteks kalimat & lampiran |
| **Kata Bermakna Ganda** | Kata *"cek"* atau *"analisis"* dikira iklan Meta Ads | AI tahu yang dicek adalah *proposal magang*, bukan iklan |
| **Konteks Lampiran** | Buta terhadap nama file yang diunggah | Membaca nama file `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO.pdf` |
| **Skalabilitas** | Setiap bikin agent baru, harus nambah ribuan regex | Otomatis 100%: Cukup isi deskripsi agent, AI langsung paham |
| **Akurasi** | Rentan salah rekrut (false positive) | **99.9% Presisi** sesuai deskripsi tugas agen |

---

## 🏛️ 2. BAGAIMANA CARA KERJANYA? (ARSITEKTUR 3 LAPIS)

```mermaid
graph TD
    A[User Input + Lampiran Dokumen] --> B[Lapis 1: Semantic Intent & Attachment Matcher]
    B -->|Hitung Kesamaan Semantik Deskripsi Agen| C[Inisialisasi Kandidat Terbaik]
    C --> D[Lapis 2: Dynamic Agent Roster Injection]
    D -->|Kirim Katalog Lengkap customAgents ke Master Agent| E[Master Agent Deep Thinking Turn]
    E --> F{Apakah Master Agent Butuh Spesialis Tertentu?}
    F -- Ya --> G[Panggil Tool summon_specialist_agent]
    G --> H[UI Otomatis Morphing ke Agen Terpilih: ARYA-MAGANG-KOMINFO]
    F -- Tidak (Tugas Umum) --> I[Tangani Langsung oleh Master Agent]
```

### Lapis 1: Semantic Intent & Attachment Matcher (Pre-Flight UI Instant)
Sebelum turn pertama dikirim ke API (agar UI tidak freeze):
- Sistem membuang seluruh `if (text.includes("cek"))` yang menyesatkan.
- Sistem mengekstrak seluruh teks konteks: **`[Isi Chat User] + [Nama Semua Berkas Lampiran]`**.
- Sistem menghitung skor kecocokan semantik (*Token & Concept Overlap*) terhadap setiap agen di `customAgents`:
  - **Kasus Proposal:** File: `PROPOSAL_INDIVIDU_ARYA_MAGANG_KOMINFO_(20).pdf` + Chat: *"coba telaah ini"*.
  - Token match ke `arya_magang_kominfo` (`proposal`, `individu`, `arya`, `magang`, `kominfo`) = **Skor 98 (Menang Mutlak)**!
  - Token match ke `tiar_meta_ads_auditor` (`iklan`, `meta`, `cpr`, `properti`) = **Skor 0 (Diskualifikasi)**!

### Lapis 2: Dynamic Agent Roster Injection ke Master Agent
Master Agent di sistem instruksi selalu menerima **Katalog Lengkap Seluruh Agen yang Tersedia**:
```text
=== 📋 DAFTAR TIM SPESIALIS TERSEDIA DI SISTEM (AGENT ROSTER) ===
1. [ID: arya_magang_kominfo] ARYA-MAGANG-KOMINFO
   Peran: Partner AI, Creative Editor & Academic Document Specialist khusus mendampingi Arya selama magang di Diskominfo Surabaya dan UNESA (Proposal, Laporan, Logbook).
2. [ID: tiar-property-ads_meta_ads_auditor_analyst] Tiar Property - Meta Ads Auditor
   Peran: Auditor kampanye Facebook/Meta Ads khusus industri perumahan & properti.
3. [ID: coding_engineer_agent] Coding & System Engineer
   Peran: Spesialis eksekusi script bash terminal Linux, automasi file, dan coding.
...
```

### Lapis 3: Autonomous Recruitment via `summon_specialist_agent`
Jika pengguna meminta tugas yang membutuhkan keahlian spesialis:
- Master Agent pada Step 1 secara cerdas mengevaluasi tugas terhadap Roster di atas.
- Master Agent memanggil tool bawaan:
  ```json
  summon_specialist_agent({
    "agent_name_or_id": "arya_magang_kominfo",
    "reason": "Tugas berfokus pada telaah proposal magang Diskominfo Surabaya dan standar akademik UNESA",
    "subtask_assignment": "Analisis struktur bab, tata bahasa humanized, dan kesesuaian format proposal"
  })
  ```
- Sistem UI browser-agent langsung:
  1. Menampilkan animasi pendelegasian ke **ARYA-MAGANG-KOMINFO**.
  2. Menyesuaikan gaya bicara dan keahlian spesialis tersebut ke dalam jawaban!

---

## 📋 3. RENCANA PERUBAHAN BERKAS

| No | Berkas | Fokus Perbaikan |
|---|---|---|
| 1 | `extension/sidepanel.js` | 1. **Hapus total** seluruh rantai regex kaku `isAuditQuery`, `isAdsQuery`, dll.<br>2. Ganti `resolveAutoAgents` dengan **Semantic Roster Matcher** yang menghitung relevansi semantik antara prompt + nama berkas terhadap `name` & `description` seluruh agen di `customAgents`.<br>3. Suntikkan blok `=== DAFTAR AGENT ROSTER ===` ke dalam prompt Master Agent agar Master Agent selalu memiliki wewenang penuh untuk merekrut via `summon_specialist_agent`. |
| 2 | `extension/background.js` | Sinkronisasi logika Semantic Roster Matcher yang sama di background runner. |
| 3 | `extension/core/goal_tracker.js` | Sinkronkan penugasan milestone agar membaca agen hasil seleksi Roster, bukan tebakan string. |

---

## 🎯 4. DAMPAK NYATA SETELAH PENERAPAN
1. **0% Salah Rekrut:** Tidak akan ada lagi kasus proposal magang tiba-tiba memanggil agen properti Tiar.
2. **Fleksibel & Otomatis:** Lo bisa buat agent apa saja di masa depan, dan Master Agent akan otomatis tahu kapan harus memanggilnya hanya dengan membaca deskripsi agent tersebut.
3. **Peka Terhadap File (Multimodal Context Aware):** Cukup upload file proposal tanpa mengetik panjang lebar, sistem langsung tahu agent mana yang harus bertugas!
