# 🏛️ Technical Audit & Reality Check: Claude Fable 5 & Opus 5 Distill Plugin

## 📌 1. Goal Description & Executive Summary
Pengguna menanyakan secara kritis:
> *"mau tanya plugin fable5 sama opus 5 distill itu bulshit apa bneran ngaruh bro"*

Dokumen ini membedah **fakta teknis tanpa ilusi**:
1. Apa sebenarnya isi dari plugin **Claude Fable 5** dan **Claude Opus 5 Distill**?
2. Bagian mana yang **BENERAN NGARUH** terhadap output AI?
3. Bagian mana yang **100% BULLSHIT / GIMMICK PLACEBO** (terutama jika pengguna menggunakan 9Router)?
4. Bagaimana dampaknya terhadap konsumsi token dan kuota?

---

## 🔍 2. Anatomi Kode: Apa yang Sebenarnya Dilakukan Plugin Ini?

Di [sidepanel.js:L1249](file:///home/arya/browser-agent/extension/sidepanel.js#L1249) dan [background.js:L3610](file:///home/arya/browser-agent/extension/background.js#L3610), saat salah satu plugin ini diaktifkan, sistem memanggil `getClaudeOpus5SystemDirective()` atau `getClaudeFableSystemDirective()`.

Modul ini **TIDAK MENGUBAH MODEL ENGINE**. Ini adalah **System Prompt Engineering Injector** (teks instruksi tambahan sekitar ~450 - 600 token) yang disadur dari bocoran prompt resmi Anthropic Claude (Mythos-tier).

```mermaid
flowchart TD
    subgraph INJEKSI_PROMPT["Isi Injeksi Plugin Fable 5 / Opus 5 (~500 Token)"]
        A["1. Tag XML: <antml:reasoning_effort>75</antml:reasoning_effort>"]
        B["2. Aturan Tone: High-Dignity & Anti-Submissive (Jangan Minta Maaf Berlebihan)"]
        C["3. Aturan Kalimat Terlarang: Zero 'Berdasarkan Memori Anda...'"]
        D["4. Taksonomi Memori: /profile.md, /topics/, /areas/, tag - [stated] & [[links]]"]
        E["5. Horizon Test: Filter fakta 30 hari"]
    end

    A -->|"Di 9Router / Google / OpenAI"| F["❌ BULLSHIT (Diabaikan Server, Dianggap Teks Biasa)"]
    B -->|"Di Semua LLM (Gemini, GPT, Claude)"| G["✅ BENERAN NGARUH (Gaya Bicara Jadi Tegas & No-Fluff)"]
    C -->|"Di Semua LLM (Gemini, GPT, Claude)"| G
    D -->|"Di SQLite / Internal Memory"| H["⚠️ SETENGAH PLACEBO (AI Cuma Lebih Rapi Menulis Catatan)"]
```

---

## ⚖️ 3. Pembedahan: Apa yang Beneran Ngaruh vs Apa yang Bullshit

### ✅ A. Yang BENERAN NGARUH (Real Impact):
1. **Gaya Bicara Tegas & Berwibawa (*High Dignity & Anti-Submissive*)**:
   - Aturan *"Accountability without self-abasement"* beneran membuat model LLM apa pun (Gemini, GPT-4o, Claude) **berhenti meminta maaf secara lebay/budak** saat dikritik pengguna. AI langsung mengakui titik salah dan fokus ke solusi teknis.
2. **Zero Basa-Basi (*Direct Prose & No Fluff*)**:
   - AI berhenti menggunakan kalimat pembuka klise seperti *"Tentu, dengan senang hati saya akan membantu Anda..."* dan penutup *"Semoga membantu!"*. Jawabannya langsung *to the point*.
3. **Pemberantasan Kalimat Cringe Memori (*Forbidden Phrases*)**:
   - AI dilarang keras berkata: *"Berdasarkan ingatan saya tentang Anda..."* atau *"Menurut profil Anda..."*. Fakta memori langsung diterapkan secara natural tanpa terkesan menguntit/mengintai (*no surveillance feel*).

---

### ❌ B. Yang 100% BULLSHIT / GIMMICK (Terutama di 9Router):
1. **Tag `<antml:reasoning_effort>75</antml:reasoning_effort>`**:
   - Tag ini adalah format eksklusif sistem internal Anthropic Claude (Claude 3.7 hybrid reasoning infra).
   - Karena Anda memakai **9Router** yang merutekan ke **Google Antigravity / Gemini** dan **OpenAI Codex**:
     **Server Google dan OpenAI TIDAK MENGERTI dan TIDAK MEMBACA tag XML `<antml:...>`!**
     Bagi Gemini dan OpenAI, tag itu cuma dianggap teks dongeng biasa seperti `<magic:power>99</magic:power>`. Server backend TIDAK AKAN mengaktifkan rantai penalaran khusus hanya gara-gara ada tag XML buatan Anthropic tersebut.
   - Di OpenAI / Gemini, pengaturan reasoning resmi dikontrol lewat parameter API `reasoning: { effort: "high" }` atau budget token, bukan lewat tag teks di dalam prompt.
2. **Ilusi "Distilled Model"**:
   - Mengaktifkan plugin ini **TIDAK MENGUBAH** model Anda menjadi "Claude Opus 5" atau "Claude Fable 5". Model di balik layar tetap Gemini Flash / Gemini Pro / GPT-5 Codex di akun 9Router Anda.
   - Ini murni *Roleplay Persona*, bukan distilasi bobot neural network (*weights distillation*).
3. **Membakar Kuota Token (~500 Token Tambahan Per Request)**:
   - Teks instruksi Opus 5 / Fable 5 panjangnya sekitar 450 - 600 token.
   - Setiap kali Anda mengetik satu kata saja (misal: *"halo"*), prompt lo otomatis digelembungkan +500 token.
   - Kalau tadi lo nanya soal hemat token, **menyalakan plugin ini justru membakar 500 token kuota ekstra di setiap turn percakapan!**

---

## 📊 4. Matriks Realitas Teknis

| Fitur di Plugin | Klaim Plugin | Realitas Teknis di 9Router | Status |
| :--- | :--- | :--- | :--- |
| **Gaya Bahasa No-Fluff** | Menghilangkan basa-basi | Model Gemini/GPT mematuhi prompt dan bicara lebih lugas | ✅ **REAL** |
| **Anti-Submissive Tone** | Menghentikan minta maaf lebay | Berhasil mencegah AI menjilat/merendahkan diri | ✅ **REAL** |
| **Forbidden Memory Phrases** | Hapus kata "Berdasarkan memori" | AI tidak lagi mengulang kalimat canggung | ✅ **REAL** |
| **`<antml:reasoning_effort>`** | Mengatur kedalaman IQ model | Diabaikan total oleh Google & OpenAI di 9Router | ❌ **BULLSHIT** |
| **Model Opus 5 Asli** | Menghadirkan kecerdasan Opus 5 | Tetap model Gemini/Codex biasa yang disuruh akting | ❌ **BULLSHIT** |
| **Efisiensi Token** | Optimasi performa | Menambah beban ~500 token di setiap pesan | ❌ **BULLSHIT (Malah Boros)** |

---

## 💡 5. Rekomendasi & Rencana Tindakan

1. **Jika lo suka gaya bicara AI yang tegas, dingin, to-the-point, dan gak suka AI yang sering minta maaf lebay**:
   - Aturan perilakunya bagus. Tapi **TIDAK PERLU** menyuntikkan seluruh teks esai 500 token yang penuh tag palsu `<antml>`.
   - Kita bisa ekstrak intinya menjadi **Micro-Directive (cukup 3 baris / ~30 token)**:
     ```text
     • Direct Prose: Jawab langsung to the point tanpa basa-basi pengantar/penutup.
     • High Dignity: Akui kesalahan secara teknis tanpa minta maaf berlebihan atau submissive.
     • Silent Memory: Gunakan fakta memori secara alami tanpa menyebut "Berdasarkan ingatan saya".
     ```
   - Hasilnya: Gaya bicara dapet 100% sama mewahnya, tapi hemat 470 token di setiap request!

2. **Jika lo ingin hemat kuota di 9Router**:
   - Pastikan plugin ini tetap dalam kondisi **OFF / DISABLED** (defaultnya memang `enabled: false`).
